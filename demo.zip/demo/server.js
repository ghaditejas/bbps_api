const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mysql = require('mysql');
var request = require('request');
var api_login = require('./login');
var bill_data_api = require('./bill_data');
var get_utility_provider_api = require('./utility');
var crypto = require('crypto');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

// connection configurations
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'node_test'
});

// connect to database
mc.connect();

// login api
app.post('/login', function (req, res) {
    var login_data = req.body;
    api_login.login_authentication(login_data, function (return_data) {
        if (return_data) {
            api_login.create_token(login_data.username, function (generated_token) {
                if (generated_token) {
                    return res.send({ error: false, message: 'Login Successful', token: generated_token });
                } else {
                    return res.send({ error: true, message: 'Invalid Credentials' })
                }
            });
        } else {
            return res.send({ error: true, message: 'Invalid Credentials' })
        }
    });
});

app.post('/get_utiltyProvider',function(req,res){
    var request_data = req.body;
    bill_data_api.api_authentication(request_data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            get_utility_provider_api.get_utility(request_data,function (utility) {
                if(utility){
                    get_utility_provider_api.get_provider(utility,function (response_data) {
                        if(utility){
                            return res.send({status : 200,message:'Success',data:response_data});
                        }else{
                            return res.send({status : 500,message:'Please try after sometime'}); 
                        }
                    });
                }else{
                    return res.send({status : 500,message:'Please try after sometime'}); 
                }
            });
        }
    });
});


//add bill api
app.post('/post_bill_data', function (req, res) {
    var bill_data = req.body;
    // var checksum_string = bill_data.username+"~"+bill_data.password;
    // var shasum = crypto.createHash('md5').update(checksum_string).digest('hex');
    // console.log(shasum);
    // console.log(req.get('task'));
    bill_data_api.api_authentication(bill_data.data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            bill_data.data['customerid'] = token.USER_ID;
            bill_data_api.validate(bill_data.data, function (validate_status) {
                if (validate_status) {
                    bill_data_api.add_bill(bill_data, function (status) {
                        if (status) {
                            // request.post({
                            //     headers: { 'content-type': 'application/json', 'Accept-Charset': 'utf-8', 'Api-Key': '33769302e0812dsadasdadd' },
                            //     url: _url,
                            //     json: response_data,
                            // }, function (error, response, body) {
                            //     if (!error && body.status == "200") {
                            //         return res.send({ error: false, message: 'Success', data: response_data });
                            //     }
                            // });
                            console.log('check');
                            return res.send({ error: true, message: 'Data successfully added'});
                        } else {
                            return res.send({ error: true, message: 'Error occured please try again' });
                        }
                    });
                } else {
                    return res.send({ error: true, message: 'Invalid data' });
                }
            });
        } else {
            return res.send({ error: true, message: 'Authentication Failed' });
        }
    });

    /*test.login_authentication(bill_data,function(return_data){
        if (return_data){
            test.create_token(bill_data.username,function(generated_token){
                if(generated_token){
                    return res.send({ error: false, message: 'Login Successful',token: generated_token});
                }else{
                    return res.send({ error: true, message: 'Invalid Credentials' })
                }
            });
        }else{ 
             return res.send({ error: true, message: 'Invalid Credentials' })
        }
    });*/
});

// Retrieve all todos 
// app.post('/todos', function (req, res) {
//     var bill_data = req.body;
//     var response = bill_data_api.test(bill_data,res);
//     console.log(response.message);
//     return res.send({response})
// });

// Search for todos with ‘bug’ in their name
app.get('/todos/search/:keyword', function (req, res) {
    let keyword = req.params.keyword;
    mc.query("SELECT * FROM tasks WHERE task LIKE ? ", ['%' + keyword + '%'], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'Todos search list.' });
    });
});

// Retrieve todo with id 
app.get('/todo/:id', function (req, res) {

    let task_id = req.params.id;

    mc.query('SELECT * FROM tasks where id=?', task_id, function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results[0], message: 'Todos list.' });
    });

});

// Add a new todo  
app.post('/todo', function (req, res) {
    var _data = req.body;
    _data['value'] = '1';
    console.log(_data);
    var _url = 'http://localhost/test.php';
    request.post({
        headers: { 'content-type': 'application/json', 'Accept-Charset': 'utf-8', 'Api-Key': '33769302e0812dsadasdadd' },
        url: _url,
        json: _data
    }, function (error, response, body) {
        if (!error) {
            console.log(body);
        }
    });

    res.send("Hello");
    /*let task = req.body.task;
    if (!task) {
        return res.status(400).send({ error:true, message: 'Please provide taskasdasd' });
    }
 
    mc.query("INSERT INTO tasks SET ? ", { task: task }, function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'New task has been created successfully.' });
    });*/
});

//  Update todo with id
app.put('/todo', function (req, res) {

    let task_id = req.body.task_id;
    let task = req.body.task;

    if (!task_id || !task) {
        return res.status(400).send({ error: task, message: 'Please provide task and task_id' });
    }

    mc.query("UPDATE tasks SET task = ? WHERE id = ?", [task, task_id], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'Task has been updated successfully.' });
    });
});

//  Delete todo
app.delete('/todo/:id', function (req, res) {

    let task_id = req.params.id;

    mc.query('DELETE FROM tasks WHERE id = ?', [task_id], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'Task has been updated successfully.' });
    });

});

// all other requests redirect to 404
app.all("*", function (req, res, next) {
    return res.send('page not found');
    next();
});

// port must be set to 8080 because incoming http requests are routed from port 80 to port 8080
app.listen(8080, function () {
    console.log('Node app is running on port 8080');
});

// allows "grunt dev" to create a development server with livereload
module.exports = app;