const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mysql = require('mysql');
var request = require('request');
var api_login = require('./login');
var bill_data_api = require('./bill_data');
var get_utility_provider_api = require('./utility');
var invoice = require('./invoice');
var wallet_create = require('./create_wallet');
var wallet_history = require('./wallet_history');
var wallet_topup = require('./wallet_topup');
var crypto = require('crypto');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

// connection configurations
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'node_test'
});

// connect to database
mc.connect();

// login api
app.post('/login', function (req, res) {
    var login_data = req.body;
    api_login.login_authentication(login_data, function (return_data) {
        if (return_data) {
            api_login.create_token(login_data.username, function (generated_token) {
                if (generated_token) {
                    return res.send({ error: false, message: 'Login Successful', token: generated_token });
                } else {
                    return res.send({ error: true, message: 'Invalid Credentials' })
                }
            });
        } else {
            return res.send({ error: true, message: 'Invalid Credentials' })
        }
    });
});

app.post('/get_utiltyProvider', function (req, res) {
    var request_data = req.body;
    bill_data_api.api_authentication(request_data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            get_utility_provider_api.get_utility(request_data, function (utility) {
                if (utility) {
                    get_utility_provider_api.get_provider(utility, function (response_data) {
                        if (utility) {
                            return res.send({ status: 200, message: 'Success', data: response_data });
                        } else {
                            return res.send({ status: 500, message: 'Please try after sometime' });
                        }
                    });
                } else {
                    return res.send({ status: 500, message: 'Please try after sometime' });
                }
            });
        }
    });
});


//add bill api
app.post('/post_bill_data', function (req, res) {
    var bill_data = req.body;
    // var checksum_string = bill_data.username+"~"+bill_data.password;
    // var shasum = crypto.createHash('md5').update(checksum_string).digest('hex');
    // console.log(shasum);
    // console.log(req.get('task'));
    bill_data_api.api_authentication(bill_data.data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            bill_data.data['customerid'] = token.USER_ID;
            bill_data_api.validate(bill_data.data, function (validate_status) {
                if (validate_status) {
                    bill_data_api.add_bill(bill_data, function (status) {
                        if (status) {
                            if (bill_data.data.servicetype == 0) {
                                var _url = "";
                            } else {
                                var _url = "";
                            }
                            request.post({
                                headers: { 'content-type': 'application/json', 'Accept-Charset': 'utf-8', 'Api-Key': '33769302e0812dsadasdadd' },
                                url: _url,
                                json: response_data,
                            }, function (error, response, body) {
                                if (!error && body.status == "200") {
                                    return res.send({ error: false, message: 'Success', data: status });
                                } else {
                                    return res.send({ error: true, message: 'Error occured please try again' });
                                }
                            });
                        } else {
                            return res.send({ error: true, message: 'Error occured please try again' });
                        }
                    });
                } else {
                    return res.send({ error: true, message: 'Invalid data' });
                }
            });
        } else {
            return res.send({ error: true, message: 'Authentication Failed' });
        }
    });
});

app.post('/post_invoice', function (req, res) {
    var invoice_data = req.body;
    bill_data_api.api_authentication(invoice_data.data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            invoice.generate_invoice(invoice_data, function (invoice_id) {
                if (invoice_id) {
                    invoice.update_bills(invoice_data, invoice_id, function (invoice_status) {
                        if (invoice_status) {
                            invoice_data.data['invoiceno'] = invoice_id;
                            invoice_data.data['invoiceurl'] = 'partnerpay.co.in/bbps/default/payment?invoice_id=' + invoice_id;
                            return res.send({ error: false, message: 'Success', data: invoice_data });
                        } else {
                            return res.send({ error: true, message: 'Authentication Failed' });
                        }
                    });
                } else {
                    return res.send({ error: true, message: 'Authentication Failed' });
                }
            });
        } else {
            return res.send({ error: true, message: 'Authentication Failed' });
        }
    });
});

app.post('/post_wallet', function (req, res) {
    var create_wallet = req.body;
    bill_data_api.api_authentication(create_wallet.data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            wallet_create.get_merchant_details(create_wallet.data, function (merchant_data) {
                if (merchant_data) {
                    var response_data = {};
                    response_data['mercid'] = create_wallet.data['merchantid'];
                    response_data['buyerEmail'] = create_wallet.data['email'];
                    response_data['buyerFirstName'] = create_wallet.data['firstname'];
                    response_data['buyerLastName'] = create_wallet.data['lastname'];
                    response_data['buyerPhone'] = create_wallet.data['mobile'];
                    // response_data['UID'] = Math.floor(Math.random())+1;
                    response_data['UID'] = "";
                    response_data['outputFormat'] = 'json';
                    response_data['privatekey'] = crypto.createHash('sha256').update(create_wallet.data['secretkey']+"@"+merchant_data.AIRPAY_USERNAME+":|:"+merchant_data.AIRPAY_PASSWORD).digest('hex');;
                    date_today = new Date().toISOString().slice(0, 19).split('T');
                    response_data['checksum'] = crypto.createHash('md5').update(response_data['buyerEmail'] + response_data['buyerPhone'] + response_data['buyerFirstName'] + response_data['buyerLastName'] + response_data['UID'] + date_today[0] + response_data['privatekey']).digest('hex');
                    console.log(response_data);
                    request.post({
                        headers: { 'content-type': 'application/json', 'Accept-Charset': 'utf-8', 'Cache-Control': 'no-cache'},
                        url: 'https://devel-payments.airpayme.com/wallet/api/walletCreate.php',
                        "rejectUnauthorized": false,
                        formData : response_data,
                        // body : {response_data},
                    }, function (error, response, body) {
                        if (!error) {
                            wallet_create.update_token(JSON.parse(body), function (token_update_status) {
                            if (token_update_status) {
                                return res.send({ error: false, message: 'Success', data: body });
                            }else{
                                return res.send({ error: false, message: 'Success', data: body });
                            }
                            });
                        } else {
                            console.log(error);
                            return res.send({ error: true, message: 'Error occured please try again' });
                        }
                    });
                } else {
                    return res.send({ error: true, message: 'Authentication Failed' });
                }
            })

        } else {
            return res.send({ error: true, message: 'Authentication Failed' });
        }
    });
});

app.post('/post_wallet_history', function (req, res) {
    var history_wallet = req.body;
    bill_data_api.api_authentication(history_wallet.data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            wallet_history.get_merchant_details(history_wallet.data, function (merchant_data) {
                if (merchant_data) {
                    var response_data = {};
                    response_data['mercid'] = history_wallet.data['merchantid'];
                    response_data['token'] = merchant_data.WALLET_TOKEN;
                    response_data['displayorder'] = 'desc';
                    response_data['displayrec'] = '1000';
                    response_data['walletUser'] = history_wallet.data['email'];
                    // response_data['UID'] = Math.floor(Math.random())+1;
                    response_data['displaypage'] = "1";
                    response_data['outputFormat'] = 'json';
                    response_data['privatekey'] = crypto.createHash('sha256').update(history_wallet.data['secretkey']+"@"+merchant_data.AIRPAY_USERNAME+":|:"+merchant_data.AIRPAY_PASSWORD).digest('hex');;
                    date_today = new Date().toISOString().slice(0, 19).split('T');
                    response_data['checksum'] = crypto.createHash('md5').update(response_data['mercid'] + response_data['token'] + response_data['walletUser'] + response_data['displayorder'] + response_data['displaypage'] + response_data['displayrec'] + date_today[0] + response_data['privatekey']).digest('hex');
                    console.log(response_data);
                    request.post({
                        headers: { 'content-type': 'application/json', 'Accept-Charset': 'utf-8', 'Cache-Control': 'no-cache'},
                        url: 'https://devel-payments.airpayme.com/wallet/api/walletHistory.php',
                        "rejectUnauthorized": false,
                        formData : response_data,
                        // body : {response_data},
                    }, function (error, response, body) {
                        if (!error) {
                            return res.send({ error: false, message: 'Success', data: body });
                        } else {
                            console.log(error);
                            return res.send({ error: true, message: 'Error occured please try again' });
                        }
                    });
                } else {
                    return res.send({ error: true, message: 'Authentication Failed' });
                }
            })

        } else {
            return res.send({ error: true, message: 'Authentication Failed' });
        }
    });
});

app.post('/post_wallet_topup', function (req, res) {
    var topup_wallet = req.body;
    bill_data_api.api_authentication(topup_wallet.data, function (token) {
        if (crypto.createHash('md5').update(token.TOKEN).digest('hex') == req.get('token')) {
            wallet_topup.get_merchant_details(topup_wallet.data, function (merchant_data) {
                if (merchant_data) {
                    var response_data = {};
                    response_data['mercid'] = topup_wallet.data['merchantid'];
                    response_data['token'] = merchant_data.WALLET_TOKEN;
                    response_data['walletUser'] = topup_wallet.data['email'];
                    response_data['txnmode'] = 'credit';
                    response_data['orderid'] = Math.floor(Math.random())+1;
                    response_data['amount'] = topup_wallet.data['amount'];
                    response_data['mer_dom'] = Buffer.from(encodeURIComponent('http://localhost')).toString('base64');
                    response_data['outputFormat'] = 'json';
                    response_data['privatekey'] = crypto.createHash('sha256').update(topup_wallet.data['secretkey']+"@"+merchant_data.AIRPAY_USERNAME+":|:"+merchant_data.AIRPAY_PASSWORD).digest('hex');;
                    date_today = new Date().toISOString().slice(0, 19).split('T');
                    response_data['checksum'] = crypto.createHash('md5').update(response_data['mercid'] + response_data['token'] + response_data['walletUser'] + response_data['txnmode'] + response_data['orderid'] + response_data['amount'] + date_today[0] + response_data['privatekey']).digest('hex');
                    console.log(response_data);
                    request.post({
                        headers: { 'content-type': 'application/json', 'Accept-Charset': 'utf-8', 'Cache-Control': 'no-cache'},
                        url: 'https://devel-payments.airpayme.com/wallet/api/walletTxn.php',
                        "rejectUnauthorized": false,
                        formData : response_data,
                        // body : {response_data},
                    }, function (error, response, body) {
                        if (!error) {
                            return res.send({ error: false, message: 'Success', data: body });
                        } else {
                            console.log(error);
                            return res.send({ error: true, message: 'Error occured please try again' });
                        }
                    });
                } else {
                    return res.send({ error: true, message: 'Authentication Failed' });
                }
            })

        } else {
            return res.send({ error: true, message: 'Authentication Failed' });
        }
    });
});
// Search for todos with ‘bug’ in their name
/*app.get('/todos/search/:keyword', function (req, res) {
    let keyword = req.params.keyword;
    mc.query("SELECT * FROM tasks WHERE task LIKE ? ", ['%' + keyword + '%'], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'Todos search list.' });
    });
});

// Retrieve todo with id 
app.get('/todo/:id', function (req, res) {

    let task_id = req.params.id;

    mc.query('SELECT * FROM tasks where id=?', task_id, function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results[0], message: 'Todos list.' });
    });

});

// Add a new todo  
app.post('/todo', function (req, res) {
    var _data = req.body;
    _data['value'] = '1';
    console.log(_data);
    var _url = 'http://localhost/test.php';
    request.post({
        headers: { 'content-type': 'application/json', 'Accept-Charset': 'utf-8', 'Api-Key': '33769302e0812dsadasdadd' },
        url: _url,
        json: _data
    }, function (error, response, body) {
        if (!error) {
            console.log(body);
        }
    });

    res.send("Hello");
    /*let task = req.body.task;
    if (!task) {
        return res.status(400).send({ error:true, message: 'Please provide taskasdasd' });
    }
 
    mc.query("INSERT INTO tasks SET ? ", { task: task }, function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'New task has been created successfully.' });
    });
});*/

//  Update todo with id
app.put('/todo', function (req, res) {

    let task_id = req.body.task_id;
    let task = req.body.task;

    if (!task_id || !task) {
        return res.status(400).send({ error: task, message: 'Please provide task and task_id' });
    }

    mc.query("UPDATE tasks SET task = ? WHERE id = ?", [task, task_id], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'Task has been updated successfully.' });
    });
});

//  Delete todo
app.delete('/todo/:id', function (req, res) {

    let task_id = req.params.id;

    mc.query('DELETE FROM tasks WHERE id = ?', [task_id], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'Task has been updated successfully.' });
    });

});

// all other requests redirect to 404
app.all("*", function (req, res, next) {
    return res.send('page not found');
    next();
});

// port must be set to 8080 because incoming http requests are routed from port 80 to port 8080
app.listen(8080, function () {
    console.log('Node app is running on port 8080');
});

// allows "grunt dev" to create a development server with livereload
module.exports = app;