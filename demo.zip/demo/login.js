const mysql = require('mysql');
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'partnerpay'
});
mc.connect();
module.exports.login_authentication = function (test,callback){
    mc.query("SELECT * FROM api_user WHERE MERCID = '"+test.mercid+"' AND USERNAME = '"+test.username+"' AND PASSWORD = '"+test.password+"'", function (error, results, fields) {
        if (error) {
            return callback(false);   
        }else if(results.length == 0){
            return callback(false);   
        }else{
            return callback(true);   
            // module.export. false;
        }
    });
}

module.exports.create_token = function(username,callback){
    let r = Math.random().toString(36).substring(6);
    var d = new Date();
    var time = d.getTime();
    mc.query("UPDATE api_user SET TOKEN = '"+r+"', TOKEN_CREATED = "+(time/1000)+",MODIFIED_ON = "+(time/1000)+" WHERE USERNAME = '"+username+"'", function (error, results, fields) {
        if (error){
            console.log(error);
            return callback(false);
        }else{
          return callback(r);
        }
    });
}