const async = require('async');
const mysql = require('mysql');
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'partnerpay'
});
mc.connect();
module.exports.api_authentication = function (test, callback) {
    mc.query("SELECT TOKEN,USER_ID FROM api_user WHERE MERCID = '" + test.merchantid + "'", function (error, results, fields) {
        if (error) {
            return callback(false);
        } else if (results.length == 0) {
            return callback(" ");
        } else {
            return callback(results[0]);
            // module.export. false;
        }
    });
}

module.exports.add_bill = function (bill_data, callback) {
    mc.query("Select FIELDS,VALIDATIONS from tbl_provider where provider_id = '" + bill_data.data.providerid + "'", function (error, results, fields) {
        if (error) {
            return callback(false);
        } else {
            fields = results[0]['FIELDS'].split('|');
            validation = results[0]['VALIDATIONS'].split('::');
            console.log(fields);
            if (bill_data.data.servicetype == 0) {
                register(bill_data,function(status){
                    console.log(status);
                    if(status){
                        return callback(true);
                    }else{
                        return callback(false);
                    }
                });
            } else {
                for (var key in bill_data.data.billdata) {
                    var details = {};
                    for (var keys in fields) {
                        field_name = fields[keys].replace(" ", "_");
                        details[fields[keys]] = bill_data.data.billdata[key][field_name];
                    }
                    mc.query("INSERT INTO tbl_provider_bill_details (FNAME,LNAME,EMAIL,MOBILE_NUMBER,DETAILS,ACCOUNT_NO,PROVIDER_ID,UTILITY_ID) VALUES('" + bill_data.data.billdata[key]['firstname'] + "','" + bill_data.data.billdata[key]['lastname'] + "','" + bill_data.data.billdata[key]['email'] + "','" + bill_data.data.billdata[key]['mobile'] + "','" + JSON.stringify(details) + "','" + bill_data.data.billdata[key]['mobile'] + "','" + bill_data.data.providerid + "','" + bill_data.data.utilityid + "')", function (error, results, fields) {
                        if (error) {
                            console.log(error);
                            return callback(false);
                        }
                    });
                }
                return callback(true);
            }
        }
    });//   return callback(false,bill_data);
}

module.exports.validate = function (billdetails, callback) {
    mc.query("Select FIELDS,VALIDATIONS from tbl_provider where provider_id = '" + billdetails.providerid + "'", function (error, results, fields) {
        if (error) {
            console.log(error);
            return callback(false);
        } else if (results.length == 0) {
            console.log(results.length);
            return callback(false);
        } else {
            var fields = results[0]['FIELDS'].split('|');
            var validation = results[0]['VALIDATIONS'].split('::');
            for (var key in billdetails.billdata) {
                if (/^[A-Za-z\s]{1,50}$/.test(billdetails.billdata[key]['firstname']) && /^[A-Za-z\s]{1,50}$/.test(billdetails.billdata[key]['lastname']) && /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(billdetails.billdata[key]['email'])) {
                    // console.log('in');
                    for (var keys in fields) {
                        var validate = new RegExp(validation[keys]);
                        field_name = fields[keys].replace(" ", "_");
                        if (validate.test(billdetails.billdata[key][field_name])) {
                            continue;
                        } else {
                            // console.log('inside');
                            return callback(false);
                        }
                    }
                } else {
                    // console.log('out');
                    return callback(false);
                }
            }
            return callback(true);
        }
    });
}


function register(bill_data, callback) {
    async.forEachOf(bill_data.data.billdata, function (value, key, call) {
                mc.query("Select ID from tbl_registered_account where ACCOUNT_NO = '" + bill_data.data.billdata[key]['mobile'] + "'", function (error, results, fields) {
                if (error) {
                    return call(false);
                } else if (results.length == 0) {
                    console.log(key);
                    mc.query("Insert into tbl_registered_account (UTILITY_ID,PROVIDE_ID,ACCOUNT_NO) VALUES('" + bill_data.data.utilityid + "','" + bill_data.data.providerid + "','" + bill_data.data.billdata[key]['mobile'] + "')", function (error, results, fields) {
                        if (error) {
                            return call(false);
                        }
                    });
                }
            });
            call(true);
    }, function (err) {
        console.log(err);
        if(err)
         return callback(err)
    });

}