const async = require('async');
const mysql = require('mysql');
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'partnerpay'
});
mc.connect();
/*module.exports.api_authentication = function (test, callback) {
    mc.query("SELECT TOKEN,USER_ID FROM api_user WHERE MERCID = '" + test.merchantid + "'", function (error, results, fields) {
        if (error) {
            console.log(error);
            return callback(false);
        } else if (results.length == 0) {
            return callback(" ");
        } else {
            return callback(results[0]);
            // module.export. false;
        }
    });
}*/

module.exports.generate_invoice = function(invoice_data, callback) {
    var d = new Date(),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    mc.query("Insert into tbl_provider_invoice (STATUS,CREATED_DATE) VALUES ('pending','" + new Date().toISOString().slice(0, 19).replace('T', ' ')+"')", function (error, results, fields) {
        if (error) {
            console.log(error);
            return callback(false);
        } else {
            return callback(results.insertId);
        }
    });//   return callback(false,bill_data);
}

module.exports.update_bills = function (invoice_data, invoice_id, callback) {
    async.forEachOf(invoice_data.data.invoicedata, function (value, key, call) {
        mc.query("UPDATE tbl_provider_bill_details set INVOICE_ID = '"+invoice_id+"' where PROVIDER_BILL_DETAILS_ID ='"+invoice_data.data.invoicedata[key]['id']+"'", function (error, results, fields) {
            if (error) {
                return callback(false);
            } else {
                call();
            }
        });
    }, function (err) {
        if (!err) return callback(true);
    });
}


function register(bill_data, callback) {
    async.forEachOf(bill_data.data.billdata, function (value, key, call) {
        mc.query("Select ID from tbl_registered_account where ACCOUNT_NO = '" + bill_data.data.billdata[key]['mobile'] + "'", function (error, results, fields) {
            if (error) {
                return callback(false);
            } else if (results.length == 0) {
                console.log(key);
                mc.query("Insert into tbl_registered_account (UTILITY_ID,PROVIDE_ID,ACCOUNT_NO) VALUES('" + bill_data.data.utilityid + "','" + bill_data.data.providerid + "','" + bill_data.data.billdata[key]['mobile'] + "')", function (error, results, fields) {
                    if (error) {
                        return callback(false);
                    } else {
                        call();
                    }
                });
            } else {
                call();
            }
        });

    }, function (err) {
        if (!err) return callback(true);
    });
}

function insert_bill(bill_data, register, callback) {
    async.forEachOf(bill_data.data.billdata, function (value, key, call) {
        mc.query("Select PROVIDER_BILL_DETAILS_ID from tbl_provider_bill_details where ACCOUNT_NO = '" + bill_data.data.billdata[key]['mobile'] + "' AND AMOUNT =0 ", function (error, results, fields) {
            if (error) {
                return callback(false);
            } else if (results.length == 0) {
                console.log(key);
                mc.query("INSERT INTO tbl_provider_bill_details (FNAME,LNAME,EMAIL,IS_REGISTER,MOBILE_NUMBER,DETAILS,ACCOUNT_NO,PROVIDER_ID,UTILITY_ID) VALUES('" + bill_data.data.billdata[key]['firstname'] + "','" + bill_data.data.billdata[key]['lastname'] + "','" + bill_data.data.billdata[key]['email'] + "','" + register + "','" + bill_data.data.billdata[key]['mobile'] + "','" + bill_data.data.billdata[key]['details'] + "','" + bill_data.data.billdata[key]['mobile'] + "','" + bill_data.data.providerid + "','" + bill_data.data.utilityid + "')", function (error, results, fields) {
                    if (error) {
                        return callback(false);
                    } else {
                        bill_data.data.billdata[key]['refid'] = results.insertId;
                        call();
                    }
                });
            } else {
                bill_data.data.billdata[key]['refid'] = results[0]['PROVIDER_BILL_DETAILS_ID'];
                call();
            }
        });

    }, function (err) {
        if (!err) return callback(bill_data);
    });
}