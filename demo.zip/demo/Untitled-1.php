<?php

namespace app\modules\api\controllers;

use app\helpers\eurekaHelper;
use app\helpers\gingerHelper;
use app\helpers\shawmanHelper;
use app\modules\api\models\EurekaResponse;
use app\modules\api\models\Merchant;
use app\modules\api\models\PnbTransaction;
use app\modules\api\models\Transactions;
use app\modules\api\models\Pos;
use app\modules\api\models\EurekaCityDetail;
use app\modules\api\models\EurekaEmployee;
use app\modules\api\models\PosOrders;
use app\modules\api\models\Pms;
use app\modules\api\models\MerchantCharges;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

/**
 * Default controller for the `api` module
 */
class PosController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */
    public $enableCsrfValidation = false;

    public function behaviors()
    {
        return [
            'contentNegotiator' => [
                'class' => \yii\filters\ContentNegotiator::className(),
                'only' => ['create', 'transaction-detail', 'transaction-response'],
                'formats' => [
                    'application/json' => \yii\web\Response::FORMAT_JSON,
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'create' => ['POST'],
                    'transaction-detail' => ['POST'],
                    'transaction-response' => ['POST'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {

        $postdata['Pos'] = [];
        \Yii::info('data from pos for transaction id : ' . $_POST['TRANSACTIONID'], 'soapinfo');
        \Yii::info('data from pos : ' . json_encode($_POST), 'soapinfo');
        @$this->sendIPNtoTanishq($_POST);
        //echo "<pre>"; var_dump($_POST); die("here");
        /* $_POST['Pos'] = [
            'TRANSACTIONID'     => 767617,
             'APTRANSACTIONID'  => 33348,
             //MERCHANTID'       => "19122",
             'MERCHANTID'       => "9",
             'TERMINALID'       => 23445645,
             'CARDISSUER'       => "Visa",
             'CHMOD'            => 'pos',
             'AMOUNT'           => "150.10",
             'CURRENCYCODE'     => "456",
             'TRANSACTIONSTATUS' => "Success",
             'MESSAGE'           => "test message",
             'RRN'               => "123",
             'AUTHCODE'          => "2222222",
             'CUSTOMER'          => "test user",
             'CUSTOMERPHONE'     => "9898989898",
             'CARD_NUMER'        => '3333xxxx2222',
             'CUSTOMEREMAIL'     => "test@test.com",
             'TRANSACTIONTYPE'   => "355",
             'ISRISK'            => "dd",
             'IPNID'             => "23",
             'ap_SecureHash'     => "xhgfjsdyyr756874",
             'IPNURL'            => "xfndgknlk",
             'IPNPORT'            => "445",

         ];*/
        $model = new Pos();
        $postdata['Pos'] = $_POST;
        \Yii::info('data from postdata : ' . json_encode($postdata), 'soapinfo');

        $TRANSACTIONID = $postdata['Pos']['TRANSACTIONID'];

        // code starts here for shawman bill settlement


        $MID = $postdata['Pos']['MERCHANTID'];
        $TID = $postdata['Pos']['TERMINALID'];
        $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $MID])->one();

        if(!empty($merchant_data->REDIRECT_URL))
        if($MID == '22723'){
            $data = json_encode($postdata['Pos']);
        }else{
            $data = $postdata['Pos'];
        }
            $this->sendDataOverPost($merchant_data->REDIRECT_URL, $data,'POST');
        }
        //echo $MID.' '.$TID;exit;
        if ($merchant_data->CLASS_NAME == 'SHAWMAN') {

            $posorder = PosOrders::find()
                ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'REFERENCEID', 'SHAWMAN_TYPE'])
                ->andWhere([
                    'ORDER_ID' => $TRANSACTIONID,
                ])
                ->orderBy('POS_ORDER_ID DESC')
                ->asArray(true)
                ->one();

            if ($posorder['REFERENCEID']) {

                $shawmanHelper = new shawmanHelper();
                $pms_data = Pms::find()->where(['PROFILEID' => $MID])->andWhere(['TERMINALID' => $TID])->one();
                //echo '<pre>';print_r($pms_data);exit;
                $TransactionId = $postdata['Pos']['TRANSACTIONID'];

                //$billfor  =  substr($TransactionId,1);
                // $source   =  substr($TransactionId,0,1);
                // $SourceId =  $source;

                $RestaurantId = $pms_data->UNIQUEID;
                $BillFor = $TransactionId;
                // $SourceId = $SourceId ;
                $SourceId = $posorder['SHAWMAN_TYPE'];
                $DeviceId = $TID;
                $BillAmount = $postdata['Pos']['AMOUNT'];
                //  $BillAmount = $posorder['AMOUNT'];

                //code written by jayesh
                if ($posorder['AMOUNT'] < $BillAmount) {
                    $TipAmount = $BillAmount - $posorder['AMOUNT'];
                } else {
                    $TipAmount = '0.00';
                }
                \Yii::info('tip amount is : ' . $TipAmount, 'soapinfo');
                //code written by jayesh

                $TransactionStatus = $postdata['Pos']['TRANSACTIONSTATUS'];
                $AuthCode = $postdata['Pos']['AUTHCODE'];
                $RRN = $postdata['Pos']['RRN'];
                $CreditCardNo = '1009';//substr($postdata['Pos']['CARD_NUMER'],12);
                $CustomerName = $postdata['Pos']['CUSTOMER'];
                $ChargeSlipNo = '';
                $Remark = '';

                if (!is_numeric($TransactionId)) {

                    $bill_settlement = @$shawmanHelper->settleBill($RestaurantId, $BillFor, $SourceId, $DeviceId, $posorder['AMOUNT'], $TipAmount, $TransactionId, $TransactionStatus, $AuthCode, $RRN, $CreditCardNo, $CustomerName, $ChargeSlipNo, $Remark);
                    \Yii::info('showman response : ' . json_encode($bill_settlement), 'soapinfo');
                    //echo '<pre>';print_r($bill_settlement);exit;
                }
            }
            //echo '<pre>';print_r($bill_settlement);exit;
        }


        // code ends here


        //var_dump($model->load($_POST)); exit;
        // if(!empty($_POST) && $model->load(Yii::$app->request->post())) {

        @$postdata['Pos']['MERCHANTID'] = (string)((int)$_POST['MERCHANTID']);
        \Yii::info('data from merchant postdata : ' . json_encode($postdata), 'soapinfo');
        if (isset($_POST['TOKEN'])) {
            $model->scenario = 'savecardtransaction';
            error_log('IPN HIT COME FOR SAVE CARD', 0);
        } else if ($_POST['TRANSACTIONTYPE'] == '370') {
            $model->scenario = 'salecompletiontransaction';
        } else {
            $model->scenario = 'normaltransaction';
        }


        if (isset($_POST['TOKEN'])) {
            $hash = array();
            $hash['TRANSACTIONID'] = $_POST['TRANSACTIONID'];
            $hash['MERCHANTID'] = $_POST['MERCHANTID'];
            $hash['TOKEN'] = $_POST['TOKEN'];
            $hash['CARDUNIQUECODE'] = $_POST['CARDUNIQUECODE'];
            $hash['TERMINALID'] = $_POST['TERMINALID'];
            $hash['CARD_NUMBER'] = $_POST['CARD_NUMBER'];
            $hash['CARD_EXPIRY'] = $_POST['CARD_EXPIRY'];
            $hash['CARD_ISSUER'] = $_POST['CARD_ISSUER'];
            $hash['CARD_TYPE'] = $_POST['CARD_TYPE'];

            $ap_SecureHash = crc32(implode('~', $hash));

            if ($_POST['ap_SecureHash'] != $ap_SecureHash) {
                \Yii::info('secure hash mismatch : ' . json_encode($postdata['Pos']), 'soapinfo');
                $response = array(
                    'status' => '400',
                    'msg' => 'secure hash mismatch ' . $ap_SecureHash
                );
                \Yii::info('model errors pos : ' . json_encode($response), 'soapinfo');
                echo json_encode($response);
                exit;

            }
        }

        // $postdata['TRANSACTIONID'] = $_POST['TRANSACTIONID'];
        if (!empty($postdata)) {
            if ($model->load($postdata)) {
                //echo '<pre>';print_r($postdata);exit;
                if(isset($postdata['Pos']['CARD_ISSUER'])){
                    $model->CARDISSUER = $postdata['Pos']['CARD_ISSUER'];
                }
                if ($model->save()) {

                    error_log('IPN DATA SAVED TO DB', 0);
                    $connection = \Yii::$app->db;

                    if (empty($TipAmount)) {
                        $TipAmount = 0;
                    }

                    \Yii::info("UPDATE tbl_pos_orders SET TIP_AMOUNT = $TipAmount, IS_SUCCESSFUL='Y'  WHERE ORDER_ID='" . $TRANSACTIONID . "'", 'soapinfo');
                    if (!isset($_POST['TOKEN'])) {
                        $connection->createCommand("UPDATE tbl_pos_orders SET TIP_AMOUNT = $TipAmount, IS_SUCCESSFUL='Y'  WHERE ORDER_ID='" . $TRANSACTIONID . "'")->execute();
                    }


                    \Yii::info('model save pos data : ' . json_encode($postdata['Pos']), 'soapinfo');
                    $merchant = Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $model->MERCHANTID])->one();

                    if ($merchant == null)
                        throw new NotFoundHttpException('The requested page does not exist.');
                   

                   echo json_encode(['status' => '200','msg' => '']);exit;
                    // if (!empty($merchant->CLASS_NAME)) {
                    //     $classname = "\\app\\helpers\\" . $merchant->CLASS_NAME;
                    //     $methodname = $merchant->METHOD_NAME;
                    //     $apih = new $classname;
                    //     $data = $apih->$methodname($model);
                    // }


                    //$apihelper = new eurekaHelper();
                    //$datasave = $apihelper->savePosData($model);

                   
                } else {
                    echo "<pre>";
                    var_dump($model->getErrors());
                    \Yii::info('model errors pos : ' . json_encode($model->getErrors()), 'soapinfo');
                    exit;
                }
            }

        }
        //return $this->render('index');

    }

    public function actionCreate()
    {

        $status = 502;
        $message = [];


        $order_id = \Yii::$app->request->post('orderid');
        $amount = \Yii::$app->request->post('amount');
        $custom_var = \Yii::$app->request->post('customvar');
        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');
        $mobileno = \Yii::$app->request->post('mobile');
        $postxntype = \Yii::$app->request->post('postxntype');
        $originalrrn = \Yii::$app->request->post('originalrrn');
        $authcode = \Yii::$app->request->post('authcode');
        @$invoiceno = \Yii::$app->request->post('invoiceno');
        @$cardtype = \Yii::$app->request->post('cardtype');

        $post[] = [
            'orderid' => $order_id,
            'amount' => $amount,
            'customvar' => $custom_var,
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
            'mobno' => $mobileno,
        ];
        \Yii::info('model pnb/posorder for create data : ' . json_encode($post), 'soapinfo');

        $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();
    
       //08-10-2018
      if($merchant_data->IS_TXN_PROCESS == 'Y'){
            $model = PosOrders::find()
            ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE', 'POS_ORDER_ID','IS_SUCCESSFUL','CREATED_ON'])
            ->andWhere([
                'UNIQUE_ID' => $unique_id,
                'MERCHANT_ID' => $merchant_id,
                'IS_SUCCESSFUL' => 'N',
              'IS_DECLINED' => 'N'
            ])
            ->orderBy('POS_ORDER_ID DESC')
            ->asArray(true)
            ->one();
       
           $txn_time = $model['CREATED_ON'] + 300;
           
           if($txn_time > time()){
                  echo  json_encode(['status' => 500, 'message' => 'Cannot create new txn ']);exit;
           }
       }
       //ends here

        //25-05-2018
        $surcharge = 0;
        if (!empty($merchant_data)) {
            if ($merchant_data->IS_SURCHARGE_APPLY == 'Y') {
                $merchantCharges = MerchantCharges::find()
                    ->select(['CHARGES'])
                    ->andWhere([
                        'MERCHANT_ID' => $merchant_id,
                    ])
                    ->one();

                $merchantCharges = json_decode($merchantCharges->CHARGES);
                $merchantCharges = (array)$merchantCharges;
                if (!empty($cardtype)) {
                    $surcharge = $this->actionCalcamt($cardtype, $amount, $merchantCharges[$cardtype]);
                }else{ 
                    arsort($merchantCharges);
                    $merchantCharges = array_values($merchantCharges);
                    sort($merchantCharges);
                    $charges = $merchantCharges[0];
                    $surcharge = $this->actionCalcamthigher($amount, $charges);
                }
            }
        }


        // ends here

        if (!empty($merchant_data)) {
            if ($merchant_data->IS_SANDBOX == 'N') {
                $model = new PosOrders();
            } else {
                $model = new PnbTransaction();
            }
            $model->ORDER_ID = $order_id;
            $model->AMOUNT = $amount;
            $model->CUSTOM_VAR = $custom_var;
            $model->MERCHANT_ID = $merchant_id;
            $model->UNIQUE_ID = $unique_id;
            $model->MOBILE_NO = $mobileno;
            $model->POS_MODE = !empty($postxntype) ? $postxntype : "1";
            $model->ORIGINALRRN = $originalrrn;
            @$model->INVOICENO = $invoiceno;
            $model->AUTHCODE = $authcode;
            $model->CARD_TYPE = $cardtype;
            $model->SURCHARGE = $surcharge;
           $model->SITEID = 'a';
            $model->WSNO = 'a';

            if ($postxntype == '8') {
                $model->POS_MODE = '2';
            }

            if ($model->save()) {
                $status = 200;
            } else {
                $message = $model->getErrors();
            }

        } else {

            $message['MERCHANT_ID'] = "Merchant not exist.";
            //$datamsg = $message;
        }


        return ['status' => $status, 'message' => $message];
    }

    public function actionCreatetest()
    {
      
        $status = 502;
        $message = [];


        $order_id = \Yii::$app->request->post('orderid');
        $amount = \Yii::$app->request->post('amount');
        $custom_var = \Yii::$app->request->post('customvar');
        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');
        $mobileno = \Yii::$app->request->post('mobile');
        $postxntype = \Yii::$app->request->post('postxntype');
        $originalrrn = \Yii::$app->request->post('originalrrn');
        $authcode = \Yii::$app->request->post('authcode');
        @$invoiceno = \Yii::$app->request->post('invoiceno');
        @$cardtype = \Yii::$app->request->post('cardtype');

        $post[] = [
            'orderid' => $order_id,
            'amount' => $amount,
            'customvar' => $custom_var,
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
            'mobno' => $mobileno,
        ];
        \Yii::info('model pnb/posorder for create data : ' . json_encode($post), 'soapinfo');

        $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();
    
       if($merchant_data->IS_TXN_PROCESS == 'Y'){
            $model = PosOrders::find()
            ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE', 'POS_ORDER_ID','IS_SUCCESSFUL','CREATED_ON'])
            ->andWhere([
                'UNIQUE_ID' => $unique_id,
                'MERCHANT_ID' => $merchant_id,
                'IS_SUCCESSFUL' => 'N',
                'IS_DECLINED' => 'N'
            ])
            ->orderBy('POS_ORDER_ID DESC')
            ->asArray(true)
            ->one();
       
           $txn_time = $model['CREATED_ON'] + 300;
           
           if($txn_time > time()){
                  echo  json_encode(['status' => 500, 'message' => 'Cannot create new txn ']);exit;
           }
       }

        //25-05-2018
        $surcharge = 0;
        if (!empty($merchant_data)) {
            if ($merchant_data->IS_SURCHARGE_APPLY == 'Y') {
                $merchantCharges = MerchantCharges::find()
                    ->select(['CHARGES'])
                    ->andWhere([
                        'MERCHANT_ID' => $merchant_id,
                    ])
                    ->one();

                $merchantCharges = json_decode($merchantCharges->CHARGES);
                $merchantCharges = (array)$merchantCharges;
                if (!empty($cardtype)) {
                    $surcharge = $this->actionCalcamt($cardtype, $amount, $merchantCharges[$cardtype]);
                }else{
                    arsort($merchantCharges);
                    $merchantCharges = array_values($merchantCharges);
                    $charges = $merchantCharges[0];
                    $surcharge = $this->actionCalcamthigher($amount, $charges);
                }
            }
        }


        // ends here

        if (!empty($merchant_data)) {
            if ($merchant_data->IS_SANDBOX == 'N') {
                $model = new PosOrders();
            } else {
                $model = new PnbTransaction();
            }
            $model->ORDER_ID = $order_id;
            $model->AMOUNT = $amount;
            $model->CUSTOM_VAR = $custom_var;
            $model->MERCHANT_ID = $merchant_id;
            $model->UNIQUE_ID = $unique_id;
            $model->MOBILE_NO = $mobileno;
            $model->POS_MODE = !empty($postxntype) ? $postxntype : "1";
            $model->ORIGINALRRN = $originalrrn;
            @$model->INVOICENO = $invoiceno;
            $model->AUTHCODE = $authcode;
            $model->CARD_TYPE = $cardtype;
            $model->SURCHARGE = $surcharge;

            if ($postxntype == '8') {
                $model->POS_MODE = '2';
            }

            if ($model->save()) {
                $status = 200;
            } else {
                $message = $model->getErrors();
            }

        } else {

            $message['MERCHANT_ID'] = "Merchant not exist.";
            //$datamsg = $message;
        }


        return ['status' => $status, 'message' => $message];
    }

    public function strafter($string, $substring)
    {
        $pos = strpos($string, $substring);
        if ($pos === false)
            return false;
        else
            return (substr($string, $pos + strlen($substring)));
    }

    public function normalOnline($terminalid, $merchant_id, $unique_id, $merchant_data, $reference_id)
    {
        $status = 502;
        $mid = \Yii::$app->request->post('mercid');
        $model = PosOrders::find()
            ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE', 'POS_ORDER_ID'])
            ->andWhere([
                'UNIQUE_ID' => $unique_id,
                'MERCHANT_ID' => $merchant_id,
                'IS_DECLINED' => 'N'
            ])
            ->orderBy('POS_ORDER_ID DESC')
            ->asArray(true)
            ->one();

        if (!empty($model)) {
            $connection = \Yii::$app->db;
            $command = $connection->createCommand('UPDATE tbl_pos_orders SET REQUEST_TIME=' . time() . ' WHERE POS_ORDER_ID= ' . $model['POS_ORDER_ID']);
            $command->execute();
            $customvar = $model['CUSTOM_VAR'];
            $bill_details = $this->strafter($customvar, "Ref:");
            if ($bill_details) {
                $order_id = $bill_details;
            } else {
                $order_id = $model['ORDER_ID'];
            }

            if ($order_id == $reference_id || $merchant_data->CLASS_NAME == 'SHAWMAN') {
                $posmodel = Pos::find()
                    ->andWhere(['MERCHANTID' => $model['MERCHANT_ID'], 'TRANSACTIONID' => $model['ORDER_ID']])
                    ->one();
                if (empty($posmodel) || $merchant_data->CLASS_NAME == 'SHAWMAN') {
                    $status = 200;
                    $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                    $surcharge = $model['SURCHARGE'];
                    // $message['mercid'] = $model['MERCHANT_ID'];
                    $message['mercid'] = $mid;
                    $message['uniqueid'] = $model['UNIQUE_ID'];

                    if ($merchant_data->IS_SURCHARGE_APPLY == 'Y') {
                        $message['amount'] = $amount + $surcharge;
                    } else {
                        $message['amount'] = $amount;
                    }

                    $message['orderid'] = $model['ORDER_ID'];
                    $message['mobileno'] = $model['MOBILE_NO'];
                    $message['customvar'] = str_replace('|', '_', $model['CUSTOM_VAR']);
                    if ($model['POS_MODE'] < 10) {
                        $message['posmode'] = '0' . $model['POS_MODE'];
                    } else {
                        $message['posmode'] = $model['POS_MODE'];
                    }
                    $message['invoiceno'] = $model['INVOICENO'];

                    if ($model['POS_MODE'] == 2) {

                        error_log('POS Mode Found', 0);

                        if ($merchant_id < 10) {

                            $merchant_id = str_replace('0', '', $merchant_id);
                        }
                        error_log('Finding rrn from transaction table', 0);
                        $originalrrn = $model['ORIGINALRRN'];
                        $postransactiondata = Pos::find()
                            ->select(['TRANSACTIONID', 'INVOICE_NO'])
                            ->andWhere([
                                'MERCHANTID' => $merchant_id,
                                'RRN' => $originalrrn
                            ])
                            ->orderBy('POS_ID DESC')
                            ->asArray(true)
                            ->one();
                        if (empty($postransactiondata)) {
                            $sequenceno = $model['ORDER_ID'];
                            $invoiceno = $model['INVOICE_NO'];
                        } else {
                            $sequenceno = $model['ORDER_ID'];
                            $invoiceno = $postransactiondata['INVOICE_NO'];
                        }

                        if ($merchant_data->IS_ORACLE == 'Y') {
                            $invoiceno = $postransactiondata['INVOICE_NO'];
                        }


                        $model = PosOrders::find()
                            ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'INVOICENO'])
                            ->andWhere([
                                'ORDER_ID' => $sequenceno,
                            ])
                            ->orderBy('POS_ORDER_ID DESC')
                            ->asArray(true)
                            ->one();

                        $status = 200;
                        $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                        // $message['mercid'] = $model['MERCHANT_ID'];
                        $message['mercid'] = $mid;
                        $message['uniqueid'] = $model['UNIQUE_ID'];
                        $message['amount'] = $amount;
                        $message['orderid'] = $model['ORDER_ID'];
                        $message['mobileno'] = $model['MOBILE_NO'];
                        $message['customvar'] = $model['CUSTOM_VAR'];
                        //  $message['customvar'] = $model['CUSTOM_VAR'];
                        $message['posmode'] = '02';
                        $message['invoiceno'] = $invoiceno;

                        // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode | invoice number

                        if ($model['INVOICENO']) {

                            $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $model['INVOICENO'];

                        } else {

                            $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $message['invoiceno'];
                        }

                    } else if ($model['POS_MODE'] == 9) {
                        $orderId = $model['ORDER_ID'];
                        $message['mercid'] = $mid;
                        $transactiondata = Transactions::find()
                            ->select(['OTHER_AMOUNT'])
                            ->andWhere([
                                'SEQUENCENO' => $orderId,
                            ])
                            ->orderBy('TXN_ID DESC')
                            ->asArray(true)
                            ->one();

                        $other_amount = $transactiondata['OTHER_AMOUNT'];
                        $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "||" . $other_amount;
                    } else if ($model['POS_MODE'] == 10) {
                        $message['mercid'] = $mid;
                        // $posdata = Pos::find()
                        // ->andWhere(['MERCHANTID'=>$model['MERCHANT_ID'],'TERMINALID' => $terminalid , 'TRANSACTIONTYPE'=> '310'])
                        // ->orderBy('POS_ID DESC')
                        // ->one();
                        //echo '<pre>';print_r($model);exit;
                        if ($model['AUTHCODE']) {

                            $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|||" . trim($model['AUTHCODE']);

                        } else {

                            $posdata = Pos::find()
                                ->andWhere(['MERCHANTID' => trim($model['MERCHANT_ID']), 'TERMINALID' => $terminalid, 'TRANSACTIONTYPE' => '310', 'RRN' => trim($model['ORIGINALRRN'])])
                                ->orderBy('POS_ID DESC')
                                ->one();
                            // echo '<pre>';print_r($posdata);exit;
                            $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|||" . $posdata['AUTHCODE'];

                        }


                    } else if ($model['POS_MODE'] == 11) {
                        // echo 'hi';exit;
                        error_log('POS Mode Found', 0);

                        if ($merchant_id < 10) {

                            $merchant_id = str_replace('0', '', $merchant_id);
                        }
                        error_log('Finding rrn from transaction table', 0);

                        $originalrrn = $model['ORIGINALRRN'];
                        // echo $originalrrn;exit;
                        $postransactiondata = Pos::find()
                            ->select(['TRANSACTIONID', 'INVOICE_NO'])
                            ->andWhere([
                                'MERCHANTID' => $merchant_id,
                                'RRN' => $originalrrn
                            ])
                            ->orderBy('POS_ID DESC')
                            ->asArray(true)
                            ->one();

                        $sequenceno = $postransactiondata['TRANSACTIONID'];
                        $invoiceno = $postransactiondata['INVOICE_NO'];

                        if (empty($postransactiondata)) {
                            $sequenceno = $model['ORDER_ID'];
                            $invoiceno = $model['INVOICE_NO'];
                        } else {
                            $sequenceno = $postransactiondata['TRANSACTIONID'];
                            $invoiceno = $postransactiondata['INVOICE_NO'];
                        }

                        $model = PosOrders::find()
                            ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'INVOICENO'])
                            ->andWhere([
                                'ORDER_ID' => $sequenceno,
                            ])
                            ->orderBy('POS_ORDER_ID DESC')
                            ->asArray(true)
                            ->one();

                        $status = 200;
                        $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                        // $message['mercid'] = $model['MERCHANT_ID'];
                        $message['mercid'] = $mid;
                        $message['uniqueid'] = $model['UNIQUE_ID'];
                        $message['amount'] = $amount;
                        $message['orderid'] = $model['ORDER_ID'];
                        $message['mobileno'] = $model['MOBILE_NO'];
                        $message['customvar'] = $model['CUSTOM_VAR'];
                        $message['customvar'] = $model['CUSTOM_VAR'];
                        $message['posmode'] = '02';
                        //$message['invoiceno'] = $invoiceno;
                        $message['invoiceno'] = $model['INVOICENO'];

                        // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode | invoice number
                        //$message['invoiceno'] = '000012';
                        $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $message['invoiceno'];

                    } else {
                        if (empty($message['posmode'])) { // for pnb transaction
                            $message['mercid'] = $mid;
                            $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . '|01';
                        } else { // for oracle transaction
                            $message['mercid'] = $mid;
                            $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'];
                        }
                    }

                } else {
                    $message['orderid'][] = "No New record.";
                    $datamsg = $status . "| No New record.";
                }
            } else {
                $message['orderid'][] = "No Record exist.";
                $datamsg = $status . "| No Record exist.";
            }

        } else {
            $message['orderid'][] = "No Record exist.";
            $datamsg = $status . "| No Record exist.";
        }
        return $datamsg;
    }

public function actionTransactionDetailBulk()
    {
        $status = 502;
        $message = [];

        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');
        $merchant_id = (int)$merchant_id;
        $post[] = [
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
        ];

        \Yii::info('model pnb/posorder for details : ' . json_encode($post), 'soapinfo');

        if (empty($merchant_id)) {
            $datamsg = ['status' => 502 ,'message' =>'Merchant  ID cannot be blank.'];
            return json_encode($datamsg);
        }

        if (empty($unique_id)) {
            $datamsg = ['status' => 502 ,'message' =>'Unique ID cannot be blank.'];
            return json_encode($datamsg);
        }

        if (!empty($unique_id) && !empty($merchant_id)) {

            $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();
            if (empty($merchant_data)) {
                $datamsg = ['status' => 502 ,'message' => 'Merchant not exist.'];
                return json_encode($datamsg);
            }

            if (!empty($merchant_data)) {
                if ($merchant_data->IS_SANDBOX == 'N') {

                        $posmodeldata = PosOrders::find()
                        ->select(['POS_ORDER_ID','ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE','REFERENCEID'])
                        ->andWhere([
                            'UNIQUE_ID' => $unique_id,
                            'MERCHANT_ID' => $merchant_id,
                            'IS_DECLINED' => 'N'
                        ])
                        ->orderBy('POS_ORDER_ID DESC')
                        ->asArray(true)
                        ->all();
               
                    if(!empty($posmodeldata)) {
                        
                        $txndata = [];
                        foreach($posmodeldata as $model){
                         $posmodel = Pos::find()
                            ->andWhere(['MERCHANTID' => $model['MERCHANT_ID'], 'TRANSACTIONID' => $model['ORDER_ID']])
                            ->one();

                           if(empty($posmodel)) {
                       
                                $amount = bcdiv($model['AMOUNT'], 1, 2);
                                $surcharge = $model['SURCHARGE'];

                                $txndata[] = [
                                   'TRANSACTIONID' => $model['ORDER_ID'],
                                  // 'TABLENO' => $model['REFERENCEID'],
                                    'TABLENO' => @str_replace('Ref:', '', $model['CUSTOM_VAR']),
                                   'AMOUNT' => $amount,
                                   'MOBILENO' => $model['MOBILE_NO'],
                                   'TXNTYPE' => '01'
                                ];
                                
                           } 
                        }

                        if(empty($txndata)){
                            $datamsg = ['status' => '502' ,'message' => 'No Records exist.'];
                        }else{
                            $datamsg = [
                               'status' => 200,
                               'MERCHANTID' => (string) $merchant_id,
                               'UNIQUEID' => $unique_id,
                               'DATA' => $txndata
                            ];
                        }
                    } else {
                        $datamsg = ['status' => 502 ,'message' => 'No Record exist.'];
                    }
                } else {
                  $datamsg = ['status' => 502 ,'message' => 'Merchant is on sandbox mode.'];
                }
            } else {
                $datamsg = ['status' => 502 ,'message' => 'Merchant not exist.'];
            }
       } 
    \Yii::info('response end to pos devices : ' . json_encode($datamsg), 'soapinfo');

        return  json_encode($datamsg);
    }

    public function actionTransactionDetail()
    {

        $status = 502;
        $message = [];

        $terminalid = \Yii::$app->request->post('terminalid');
        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');
        $mid = $merchant_id;
        $merchant_id = (int)$merchant_id;
        $post[] = [
            'terminalid' => $terminalid,
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
        ];
          // echo '<pre>';print_r($post);exit;
        \Yii::info('model pnb/posorder for details : ' . json_encode($post), 'soapinfo');
        /*var_dump($terminalid);
        var_dump($merchant_id);
        var_dump($unique_id); exit;

        if(empty($terminalid))    {
            $message['TERMINAL_ID'][] =  "Terminal  ID cannot be blank.";
            $status = 112;
        }*/


        if (empty($merchant_id)) {
            $message['mercid'][] = "Merchant  ID cannot be blank.";
            $status = 100;
            $datamsg = $status . "| Merchant  ID cannot be blank.";
        }

        if (empty($unique_id)) {
            $message['uniqueid'][] = "Unique ID cannot be blank.";
            $status = 100;
            $datamsg = $status . "| Unique ID cannot be blank.";
        }


        if (!empty($unique_id) && !empty($merchant_id)) {

            /*$model = PnbTransaction::find()
                ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT','UNIQUE_ID','MOBILE_NO'])
                ->andWhere([
                    'UNIQUE_ID' => $unique_id,
                    'MERCHANT_ID' => $merchant_id,
                ])
                ->orderBy('PNB_TRANSACTION_ID DESC')
                ->asArray(true)
                ->one();

            if(!empty($model))  {
                $status = 200;
            	$amount  = number_format(floor($model['AMOUNT']*100)/100,2, '.', '');
                $message['mercid'] = $model['MERCHANT_ID'];
            	$message['uniqueid'] = $model['UNIQUE_ID'];
            	$message['amount'] = $amount;
                $message['orderid'] = $model['ORDER_ID'];
            	$message['mobileno'] = $model['MOBILE_NO'];
                $datamsg = $status."||".$message['uniqueid']."|".$message['mercid']."|".$message['amount']."|".$message['orderid']."|".$message['mobileno'];
            }   else    {
                $message['orderid'][] =  "No Record exist.";
                $datamsg = $status."| No Record exist.";
            }*/

            //$merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID'=>$merchant_id])->one();


//new updates from 5-1-2017
            $merchant_id = (int)$merchant_id;
            $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();
            if (empty($merchant_data)) {
                $message['mercid'][] = "Merchant not exist..";
                $status = 502;
                $datamsg = $status . "| Merchant not exist.";
                return $datamsg;
            } else {
                $merchant_configuration = Pms::find()->where(['PROFILEID' => $merchant_id, 'TERMINALID' => $terminalid, 'STATUS' => 'Y'])->one();
                if (!empty($merchant_configuration)) {
                    $class_name = $merchant_configuration->CLASS_NAME;
                    if ($class_name == 'SHAWMAN_OFFLINE') {
                        $offline_response = $this->normalOnline($terminalid, $merchant_id, $unique_id, $merchant_data, \Yii::$app->request->post('referenceid'));
                        return $offline_response;
                    }
                }
            }

            if (isset($_POST['referenceid']) && !empty($_POST['referenceid'])) {    //shawman
                $RestaurantId = (int)\Yii::$app->request->post('uniqueid');//unqueid
                $BillFor = \Yii::$app->request->post('referenceid');//ref id
                $billfor = substr($BillFor, 1);
                $source = substr($BillFor, 0, 1);
                $SourceId = $source;  //t or b

                $DeviceId = \Yii::$app->request->post('terminalid');//terminal id

                // $RestaurantId       =       642272;
                // $BillFor            =       '10';
                // $SourceId           =       'T';
                // $DeviceId           =       '53121403';//'123';
                $shawmanHelper = new shawmanHelper();
                //echo 'initiating shawman test';
                //echo '<br/>';
                //echo '<pre>';print_r([$RestaurantId,$billfor,$SourceId,$DeviceId]);exit;
                $bill_info = $shawmanHelper->getBillInfo($RestaurantId, $billfor, $SourceId, $DeviceId);
                //echo '<pre>';print_r([$RestaurantId,$billfor,$SourceId,$DeviceId]);exit;
                //echo 'asd';
                // echo '<pre>';print_r($bill_info);exit;
                //print_r($bill_info);
                \Yii::info('shawman response for create data : ' . json_encode($bill_info), 'soapinfo');

                if ($bill_info['Result'] == 'Success') {

                    //echo 'something is wrong';
                    $order_id = $bill_info['data'][0][0]['billNo'];
                    $amount = $bill_info['data'][0][0]['BillAmount'];
                    $custom_var = 'shawman';
                    $mobileno = '';
                    $post[] = [
                        'orderid' => $order_id,
                        'amount' => $amount,
                        'customvar' => $custom_var,
                        'mercid' => $merchant_id,
                        'uniqueid' => $unique_id,
                        'mobno' => $mobileno,
                    ];
                    // echo $bill_info['data'][0][0]['BillNo'];exit;
                    \Yii::info('model pnb/posorder for create data : ' . json_encode($post), 'soapinfo');

                    $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();

                    if (!empty($merchant_data)) {
                        if ($merchant_data->IS_SANDBOX == 'N') {
                            $model = new PosOrders();
                        } else {
                            $model = new PnbTransaction();
                        }

                        $model->ORDER_ID = $order_id;
                        $model->AMOUNT = $amount;
                        $model->CUSTOM_VAR = $custom_var;
                        $model->MERCHANT_ID = $merchant_id;
                        $model->UNIQUE_ID = $unique_id;
                        $model->MOBILE_NO = $mobileno;
                        $model->POS_MODE = 1;
                        $model->REFERENCEID = $order_id;
                        $model->SHAWMAN_TYPE = $SourceId;
                        // echo '<pre>';print_r($model);exit;
                        if (!$model->save()) {

                            $message['order'][] = "Order not generated.";
                            $status = 100;
                            $datamsg = $status . "| Order not generated.";
                        }
                    }
                } else if ($bill_info['Result'] == 'Failure' && $bill_info['Errors']['Statuscode'] == 5) {

                    //echo 'sending transaction failure';exit;
                    //echo '<br/>';
                    $release_shawman_table_json = $shawmanHelper->sendFailure($RestaurantId, $BillFor, $SourceId, $DeviceId, '', '', '', 'fail', '', '', '', '', '', '');
                    $release_shawman_table_array = json_decode($release_shawman_table_json, true);
                    //print_r($release_shawman_table_array);exit;
                    if ($release_shawman_table_array['Statuscode'] == 0) {

                        //echo 'hitting bill info again';
                        //echo '<br/>';
                        $bill_info1 = $shawmanHelper->getBillInfo($RestaurantId, $billfor, $SourceId, $DeviceId);
                        //echo '<pre>';print_r($bill_info1);exit;
                        //echo 'final response';
                        //echo '<br/>';

                        if ($bill_info1['Result'] == 'Success') {
//echo 'something is wrong';

                            $order_id = $bill_info1['data'][0][0]['billNo'];
                            $amount = $bill_info1['data'][0][0]['BillAmount'];
                            $custom_var = 'shawman';
                            $mobileno = '';
                            $post[] = [
                                'orderid' => $order_id,
                                'amount' => $amount,
                                'customvar' => $custom_var,
                                'mercid' => $merchant_id,
                                'uniqueid' => $unique_id,
                                'mobno' => $mobileno,
                            ];

                            \Yii::info('model pnb/posorder for create data : ' . json_encode($post), 'soapinfo');

                            $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();

                            if (!empty($merchant_data)) {

                                if ($merchant_data->IS_SANDBOX == 'N') {
                                    $model = new PosOrders();
                                } else {
                                    $model = new PnbTransaction();
                                }
                                // echo $bill_info1['data'][0][0]['BillNo'];exit;
                                $model->ORDER_ID = $order_id;
                                $model->AMOUNT = $amount;
                                $model->CUSTOM_VAR = $custom_var;
                                $model->MERCHANT_ID = $merchant_id;
                                $model->UNIQUE_ID = $unique_id;
                                $model->MOBILE_NO = $mobileno;
                                $model->POS_MODE = 1;
                                $model->REFERENCEID = $order_id;
                                $model->SHAWMAN_TYPE = $SourceId;
                                // echo '<pre>';print_r($model);exit;
                                if (!$model->save()) {

                                    $message['order'][] = "Order not generated.";
                                    $status = 100;
                                    $datamsg = $status . "| Order not generated.";
                                }
                            }

                        } else {

                            $message['shawman'][] = $bill_info['error'];
                            $status = 100;
                            $datamsg = $status . "| Shawman api error.";
                            return $datamsg;
                        }
                    } else {

                        //echo 'something is wrong';
                        $message['shawman'][] = $bill_info['error'];
                        $status = 100;
                        $datamsg = $status . "| Shawman api error.";
                        return $datamsg;
                    }

                    //echo $datamsg;exit;
                } else if ($bill_info['Result'] == 'Failure' && $bill_info['Errors']['Statuscode'] != 5) {

                    $message['shawman'][] = $bill_info['error'];
                    $status = 100;
                    $datamsg = $status . "| Shawman api error.";
                    return $datamsg;
                }
            } else {  //oracle


                //if ($merchant_data->CLASS_NAME == 'oracle') {  commented on 26-03-2018

                $model = Pms::find()->select(['SITEID', 'WSNO'])
                    ->andWhere([
                        'PROFILEID' => $merchant_id,
                        'TERMINALID' => $terminalid,
                        'UNIQUEID' => $unique_id,
                        'STATUS' => 'Y'
                    ])
                    ->one();

                //echo '<pre>';print_r([$merchant_id,$terminalid,$unique_id,$model]);exit;

                if (!empty($model['SITEID']) && !empty($model['WSNO'])) {

                    $posdata = PosOrders::find()->select(['POS_ORDER_ID', 'ORDER_ID'])->andWhere([
                        'SITEID' => $model->SITEID,
                        'WSNO' => $model->WSNO,
                    ])
                        ->orderBy('POS_ORDER_ID DESC')
                        ->asArray(true)
                        ->one();

                    $posorderid = $posdata['POS_ORDER_ID'];

                    $psmodel = PosOrders::findOne($posorderid);
                    $psmodel->MERCHANT_ID = $merchant_id;
                    $psmodel->UNIQUE_ID = $unique_id;
                    $psmodel->CUSTOM_VAR = $merchant_id . '::' . $unique_id;
                    $psmodel->save();

                    $transactionTblData = Transactions::find()->select(['TXN_ID', 'SEQUENCENO'])->andWhere(['SEQUENCENO' => $posdata['ORDER_ID']])->one();

                    $TXN_ID = $transactionTblData['TXN_ID'];

                    $transactionModl = Transactions::findOne($TXN_ID);
                    $transactionModl->MERCHANTID = $merchant_id;
                    $transactionModl->UNIQUEID = $unique_id;
                    $transactionModl->save();

                }
                // }    commented on 26-03-2018

            }

//updates ends here
            //$merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID'=>$merchant_id])->one();

            if (!empty($merchant_data)) {
                if ($merchant_data->IS_SANDBOX == 'N') {

                    if ($merchant_data->IS_ORACLE == 'Y') {

                        $model = PosOrders::find()
                            ->select(['POS_ORDER_ID','ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE'])
                            ->andWhere([
                                'UNIQUE_ID' => $unique_id,
                                'MERCHANT_ID' => $merchant_id,
                                'IS_DECLINED' => 'N'
                            ])
                            ->andWhere(['<>', 'POS_MODE', '20'])
                            ->orderBy('POS_ORDER_ID DESC')
                            ->asArray(true)
                            ->one();

                    } else {

                        $model = PosOrders::find()
                            ->select(['POS_ORDER_ID','ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE'])
                            ->andWhere([
                                //    'UNIQUE_ID' => $unique_id,
                                'UNIQUE_ID' => \Yii::$app->request->post('uniqueid'),
                                'MERCHANT_ID' => $merchant_id,
                                'IS_DECLINED' => 'N'
                            ])
                            ->orderBy('POS_ORDER_ID DESC')
                            ->asArray(true)
                            ->one();

                    }


                    if (!empty($model)) {

                        $posmodel = Pos::find()
                            ->andWhere(['MERCHANTID' => $model['MERCHANT_ID'], 'TRANSACTIONID' => $model['ORDER_ID']])
                            ->one();

                        // if(empty($posmodel))    old code 14-11-2017
                        if (empty($posmodel) || $merchant_data->IS_ORACLE == 'Y' || $merchant_data->CLASS_NAME == 'SHAWMAN') {

                            $status = 200;
                           // $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                             $amount = bcdiv($model['AMOUNT'], 1, 2);
                            $surcharge = $model['SURCHARGE'];
                            // $message['mercid'] = $model['MERCHANT_ID'];
                            $message['mercid'] = $mid;
                            $message['uniqueid'] = $model['UNIQUE_ID'];

                            if ($merchant_data->IS_SURCHARGE_APPLY == 'Y') {
                                $message['amount'] = $amount + $surcharge;
                            } else {
                                $message['amount'] = $amount;
                            }

                            $message['orderid'] = $model['ORDER_ID'];
                            $message['mobileno'] = $model['MOBILE_NO'];
                            $message['customvar'] = str_replace('|', '_', $model['CUSTOM_VAR']);
                            if ($model['POS_MODE'] < 10) {
                                $message['posmode'] = '0' . $model['POS_MODE'];
                            } else {
                                $message['posmode'] = $model['POS_MODE'];
                            }
                            $message['invoiceno'] = $model['INVOICENO'];

                            if($merchant_id != '24351'){
                                //echo 'here';exit;
                                \Yii::$app->db->createCommand()
                                 ->update('tbl_pos_orders', ['IS_DECLINED' => 'Y'], 'POS_ORDER_ID = '.$model['POS_ORDER_ID'])
                                 ->execute();
                            }

                            if ($model['POS_MODE'] == 2) {

                                error_log('POS Mode Found', 0);

                                if ($merchant_id < 10) {

                                    $merchant_id = str_replace('0', '', $merchant_id);
                                }
                                error_log('Finding rrn from transaction table', 0);

                                // $transactiondata = Transactions::find()
                                // ->select(['ORIGINALRRN'])
                                // ->andWhere([
                                //     'UNIQUEID' => $unique_id,
                                //     'MERCHANTID' => $merchant_id,
                                //     'TRANS_TYPE' => '08'//08 for transaction type void
                                // ])
                                // ->orderBy('TXN_ID DESC')
                                // ->asArray(true)
                                // ->one();

                                // $originalrrn = $transactiondata['ORIGINALRRN'];
                                $originalrrn = $model['ORIGINALRRN'];

                                $postransactiondata = Pos::find()
                                    ->select(['TRANSACTIONID', 'INVOICE_NO'])
                                    ->andWhere([
                                        'MERCHANTID' => $merchant_id,
                                        'RRN' => $originalrrn
                                    ])
                                    ->orderBy('POS_ID DESC')
                                    ->asArray(true)
                                    ->one();


                                //this code
                                if (empty($postransactiondata)) {
                                    $sequenceno = $model['ORDER_ID'];
                                    $invoiceno = $model['INVOICENO'];
                                } else {
                                    $sequenceno = $model['ORDER_ID'];
                                    $invoiceno = $postransactiondata['INVOICE_NO'];
                                }

                                //remove this code if want same txn id on void ipn response 9-3-2018

                                // $sequenceno = $model['ORDER_ID'];
                                // $invoiceno  = $model['INVOICE_NO'];

                                if ($merchant_data->IS_ORACLE == 'Y') {
                                    $invoiceno = $postransactiondata['INVOICE_NO'];
                                }


                                $model = PosOrders::find()
                                    ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'INVOICENO'])
                                    ->andWhere([
                                        'ORDER_ID' => $sequenceno,
                                    ])
                                    ->orderBy('POS_ORDER_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $status = 200;
                                //$amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                                $amount = bcdiv($model['AMOUNT'], 1, 2);
                                // $message['mercid'] = $model['MERCHANT_ID'];
                                $message['mercid'] = $mid;
                                $message['uniqueid'] = $model['UNIQUE_ID'];
                                $message['amount'] = $amount;
                                $message['orderid'] = $model['ORDER_ID'];
                                $message['mobileno'] = $model['MOBILE_NO'];
                                $message['customvar'] = $model['CUSTOM_VAR'];
                                //  $message['customvar'] = $model['CUSTOM_VAR'];
                                $message['posmode'] = '02';
                                $message['invoiceno'] = $invoiceno;

                                // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode | invoice number

                                if ($model['INVOICENO']) {

                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $model['INVOICENO'];

                                } else {

                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $message['invoiceno'];
                                }

                            } else if ($model['POS_MODE'] == 9) {
                                $orderId = $model['ORDER_ID'];
                                $message['mercid'] = $mid;
                                $transactiondata = Transactions::find()
                                    ->select(['OTHER_AMOUNT'])
                                    ->andWhere([
                                        'SEQUENCENO' => $orderId,
                                    ])
                                    ->orderBy('TXN_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $other_amount = $transactiondata['OTHER_AMOUNT'];
                                $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "||" . $other_amount;
                            } else if ($model['POS_MODE'] == 10) {
                                $message['mercid'] = $mid;
                                // $posdata = Pos::find()
                                // ->andWhere(['MERCHANTID'=>$model['MERCHANT_ID'],'TERMINALID' => $terminalid , 'TRANSACTIONTYPE'=> '310'])
                                // ->orderBy('POS_ID DESC')
                                // ->one();
                                //echo '<pre>';print_r($model);exit;
                                if ($model['AUTHCODE']) {

                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|||" . trim($model['AUTHCODE']);

                                } else {

                                    $posdata = Pos::find()
                                        ->andWhere(['MERCHANTID' => trim($model['MERCHANT_ID']), 'TERMINALID' => $terminalid, 'TRANSACTIONTYPE' => '310', 'RRN' => trim($model['ORIGINALRRN'])])
                                        ->orderBy('POS_ID DESC')
                                        ->one();
                                    // echo '<pre>';print_r($posdata);exit;
                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|||" . $posdata['AUTHCODE'];

                                }


                            } else if ($model['POS_MODE'] == 11) {
                                // echo 'hi';exit;
                                error_log('POS Mode Found', 0);
                                $amt = $model['AMOUNT'];
                                if ($merchant_id < 10) {

                                    $merchant_id = str_replace('0', '', $merchant_id);
                                }
                                error_log('Finding rrn from transaction table', 0);

                                $originalrrn = $model['ORIGINALRRN'];
                                // echo $originalrrn;exit;
                                $postransactiondata = Pos::find()
                                    ->select(['TRANSACTIONID', 'INVOICE_NO'])
                                    ->andWhere([
                                        'MERCHANTID' => $merchant_id,
                                        'RRN' => $originalrrn
                                    ])
                                    ->orderBy('POS_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $sequenceno = $postransactiondata['TRANSACTIONID'];
                                $invoiceno = $postransactiondata['INVOICE_NO'];

                                if (empty($postransactiondata)) {
                                    $sequenceno = $model['ORDER_ID'];
                                    $invoiceno = $model['INVOICE_NO'];
                                } else {
                                    $sequenceno = $postransactiondata['TRANSACTIONID'];
                                    $invoiceno = $postransactiondata['INVOICE_NO'];
                                }

                                $model = PosOrders::find()
                                    ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'INVOICENO'])
                                    ->andWhere([
                                        'ORDER_ID' => $sequenceno,
                                    ])
                                    ->orderBy('POS_ORDER_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $status = 200;
                                $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                                // $message['mercid'] = $model['MERCHANT_ID'];
                                $message['mercid'] = $mid;
                                $message['uniqueid'] = $model['UNIQUE_ID'];
                                $message['amount'] = $amount;
                                $message['orderid'] = $model['ORDER_ID'];
                                $message['mobileno'] = $model['MOBILE_NO'];
                                $message['customvar'] = $model['CUSTOM_VAR'];
                                $message['customvar'] = $model['CUSTOM_VAR'];
                                $message['posmode'] = '02';
                                //$message['invoiceno'] = $invoiceno;
                                $message['invoiceno'] = $invoiceno;

                                // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode | invoice number
                                //$message['invoiceno'] = '000012';
                                $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $message['invoiceno'];

                            } else {

                                // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode

                                if (empty($message['posmode'])) { // for pnb transaction
                                    $message['mercid'] = $mid;
                                    // $datamsg = $status."||".$message['uniqueid']."|".$message['mercid']."|".$message['amount']."|".$message['orderid']."|".$message['mobileno']."|".$message['customvar'];  //old code
                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . '|01';
                                } else { // for oracle transaction
                                    $message['mercid'] = $mid;
                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'];
                                }


                            }

                        } else {
                            $message['orderid'][] = "No New record.";
                            $datamsg = $status . "| No New record.";
                        }
                    } else {
                        $message['orderid'][] = "No Record exist.";
                        $datamsg = $status . "| No Record exist.";
                    }
                } else {
                    $model = PnbTransaction::find()
                        ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR'])
                        ->andWhere([
                            'UNIQUE_ID' => $unique_id,
                            'MERCHANT_ID' => $merchant_id,
                        ])
                        ->orderBy('PNB_TRANSACTION_ID DESC')
                        ->asArray(true)
                        ->one();


                    if (!empty($model)) {
                        $status = 200;
                        $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                        $message['mercid'] = $model['MERCHANT_ID'];
                        $message['uniqueid'] = $model['UNIQUE_ID'];
                        $message['amount'] = $amount;
                        $message['orderid'] = $model['ORDER_ID'];
                        $message['mobileno'] = $model['MOBILE_NO'];
                        $message['customvar'] = $model['CUSTOM_VAR'];
                        $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'];
                    } else {
                        $message['orderid'][] = "No Record exist.";
                        $datamsg = $status . "| No Record exist.";
                    }
                }
            } else {
                $message['orderid'][] = "Merchant not exist.";
                $datamsg = $status . "| Merchant not exist.";
            }
        }
    \Yii::info('response end to pos devices : ' . $datamsg, 'soapinfo');
        //return ['status' => $status, 'message' => $message];
        return $datamsg;
    }


    public function actionTransactionDetailtest()
    {
 
         $status = 502;
        $message = [];

        $terminalid = \Yii::$app->request->post('terminalid');
        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');
        $mid = $merchant_id;
        $merchant_id = (int)$merchant_id;
        $post[] = [
            'terminalid' => $terminalid,
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
        ];
          // echo '<pre>';print_r($post);exit;
        \Yii::info('model pnb/posorder for details : ' . json_encode($post), 'soapinfo');
        /*var_dump($terminalid);
        var_dump($merchant_id);
        var_dump($unique_id); exit;

        if(empty($terminalid))    {
            $message['TERMINAL_ID'][] =  "Terminal  ID cannot be blank.";
            $status = 112;
        }*/


        if (empty($merchant_id)) {
            $message['mercid'][] = "Merchant  ID cannot be blank.";
            $status = 100;
            $datamsg = $status . "| Merchant  ID cannot be blank.";
        }

        if (empty($unique_id)) {
            $message['uniqueid'][] = "Unique ID cannot be blank.";
            $status = 100;
            $datamsg = $status . "| Unique ID cannot be blank.";
        }


        if (!empty($unique_id) && !empty($merchant_id)) {

            /*$model = PnbTransaction::find()
                ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT','UNIQUE_ID','MOBILE_NO'])
                ->andWhere([
                    'UNIQUE_ID' => $unique_id,
                    'MERCHANT_ID' => $merchant_id,
                ])
                ->orderBy('PNB_TRANSACTION_ID DESC')
                ->asArray(true)
                ->one();

            if(!empty($model))  {
                $status = 200;
            	$amount  = number_format(floor($model['AMOUNT']*100)/100,2, '.', '');
                $message['mercid'] = $model['MERCHANT_ID'];
            	$message['uniqueid'] = $model['UNIQUE_ID'];
            	$message['amount'] = $amount;
                $message['orderid'] = $model['ORDER_ID'];
            	$message['mobileno'] = $model['MOBILE_NO'];
                $datamsg = $status."||".$message['uniqueid']."|".$message['mercid']."|".$message['amount']."|".$message['orderid']."|".$message['mobileno'];
            }   else    {
                $message['orderid'][] =  "No Record exist.";
                $datamsg = $status."| No Record exist.";
            }*/

            //$merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID'=>$merchant_id])->one();


//new updates from 5-1-2017

            $merchant_id = (int)$merchant_id;
            $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();
            if (empty($merchant_data)) {
                $message['mercid'][] = "Merchant not exist..";
                $status = 502;
                $datamsg = $status . "| Merchant not exist.";
                return $datamsg;
            } else {
             
                $merchant_configuration = Pms::find()->where(['PROFILEID' => $merchant_id, 'TERMINALID' => $terminalid, 'STATUS' => 'Y'])->one();
                if (!empty($merchant_configuration)) {
                    $class_name = $merchant_configuration->CLASS_NAME;
                    if ($class_name == 'SHAWMAN_OFFLINE') {
                    	echo 'asd';exit;
                        $offline_response = $this->normalOnline($terminalid, $merchant_id, $unique_id, $merchant_data, \Yii::$app->request->post('referenceid'));
                        //echo 'huhuh'.$offline_response;exit;
                        return $offline_response;
                    }
                }
            }
          
            if (isset($_POST['referenceid']) && !empty($_POST['referenceid'])) {    //shawman
         
                $RestaurantId = (int)\Yii::$app->request->post('uniqueid');//unqueid
                $BillFor = \Yii::$app->request->post('referenceid');//ref id
                $billfor = substr($BillFor, 1);
                $source = substr($BillFor, 0, 1);
                $SourceId = $source;  //t or b

                $DeviceId = \Yii::$app->request->post('terminalid');//terminal id

                // $RestaurantId       =       642272;
                // $BillFor            =       '10';
                // $SourceId           =       'T';
                // $DeviceId           =       '53121403';//'123';
                $shawmanHelper = new shawmanHelper();
                //echo 'initiating shawman test';
                //echo '<br/>';
                //echo '<pre>';print_r([$RestaurantId,$billfor,$SourceId,$DeviceId]);exit;
                $bill_info = $shawmanHelper->getBillInfo($RestaurantId, $billfor, $SourceId, $DeviceId);
                //echo '<pre>';print_r([$RestaurantId,$billfor,$SourceId,$DeviceId]);exit;
                //echo 'asd';
                // echo '<pre>';print_r($bill_info);exit;
                //print_r($bill_info);
                \Yii::info('shawman response for create data : ' . json_encode($bill_info), 'soapinfo');

                if ($bill_info['Result'] == 'Success') {

                    //echo 'something is wrong';
                    $order_id = $bill_info['data'][0][0]['billNo'];
                    $amount = $bill_info['data'][0][0]['BillAmount'];
                    $custom_var = 'shawman';
                    $mobileno = '';
                    $post[] = [
                        'orderid' => $order_id,
                        'amount' => $amount,
                        'customvar' => $custom_var,
                        'mercid' => $merchant_id,
                        'uniqueid' => $unique_id,
                        'mobno' => $mobileno,
                    ];
                    // echo $bill_info['data'][0][0]['BillNo'];exit;
                    \Yii::info('model pnb/posorder for create data : ' . json_encode($post), 'soapinfo');

                    $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();

                    if (!empty($merchant_data)) {
                        if ($merchant_data->IS_SANDBOX == 'N') {
                            $model = new PosOrders();
                        } else {
                            $model = new PnbTransaction();
                        }

                        $model->ORDER_ID = $order_id;
                        $model->AMOUNT = $amount;
                        $model->CUSTOM_VAR = $custom_var;
                        $model->MERCHANT_ID = $merchant_id;
                        $model->UNIQUE_ID = $unique_id;
                        $model->MOBILE_NO = $mobileno;
                        $model->POS_MODE = 1;
                        $model->REFERENCEID = $order_id;
                        $model->SHAWMAN_TYPE = $SourceId;
                        // echo '<pre>';print_r($model);exit;
                        if (!$model->save()) {

                            $message['order'][] = "Order not generated.";
                            $status = 100;
                            $datamsg = $status . "| Order not generated.";
                        }
                    }
                } else if ($bill_info['Result'] == 'Failure' && $bill_info['Errors']['Statuscode'] == 5) {
      
                    //echo 'sending transaction failure';exit;
                    //echo '<br/>';
                    $release_shawman_table_json = $shawmanHelper->sendFailure($RestaurantId, $BillFor, $SourceId, $DeviceId, '', '', '', 'fail', '', '', '', '', '', '');
                    $release_shawman_table_array = json_decode($release_shawman_table_json, true);
                    //print_r($release_shawman_table_array);exit;
                    if ($release_shawman_table_array['Statuscode'] == 0) {

                        //echo 'hitting bill info again';
                        //echo '<br/>';
                        $bill_info1 = $shawmanHelper->getBillInfo($RestaurantId, $billfor, $SourceId, $DeviceId);
                        //echo '<pre>';print_r($bill_info1);exit;
                        //echo 'final response';
                        //echo '<br/>';

                        if ($bill_info1['Result'] == 'Success') {
//echo 'something is wrong';

                            $order_id = $bill_info1['data'][0][0]['billNo'];
                            $amount = $bill_info1['data'][0][0]['BillAmount'];
                            $custom_var = 'shawman';
                            $mobileno = '';
                            $post[] = [
                                'orderid' => $order_id,
                                'amount' => $amount,
                                'customvar' => $custom_var,
                                'mercid' => $merchant_id,
                                'uniqueid' => $unique_id,
                                'mobno' => $mobileno,
                            ];

                            \Yii::info('model pnb/posorder for create data : ' . json_encode($post), 'soapinfo');

                            $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();

                            if (!empty($merchant_data)) {

                                if ($merchant_data->IS_SANDBOX == 'N') {
                                    $model = new PosOrders();
                                } else {
                                    $model = new PnbTransaction();
                                }
                                // echo $bill_info1['data'][0][0]['BillNo'];exit;
                                $model->ORDER_ID = $order_id;
                                $model->AMOUNT = $amount;
                                $model->CUSTOM_VAR = $custom_var;
                                $model->MERCHANT_ID = $merchant_id;
                                $model->UNIQUE_ID = $unique_id;
                                $model->MOBILE_NO = $mobileno;
                                $model->POS_MODE = 1;
                                $model->REFERENCEID = $order_id;
                                $model->SHAWMAN_TYPE = $SourceId;
                                // echo '<pre>';print_r($model);exit;
                                if (!$model->save()) {

                                    $message['order'][] = "Order not generated.";
                                    $status = 100;
                                    $datamsg = $status . "| Order not generated.";
                                }
                            }

                        } else {
         
                            $message['shawman'][] = $bill_info['error'];
                            $status = 100;
                            $datamsg = $status . "| Shawman api error.";
                            return $datamsg;
                        }
                    } else {

                        //echo 'something is wrong';
                        $message['shawman'][] = $bill_info['error'];
                        $status = 100;
                        $datamsg = $status . "| Shawman api error.";
                        return $datamsg;
                    }

                    //echo $datamsg;exit;
                } else if ($bill_info['Result'] == 'Failure' && $bill_info['Errors']['Statuscode'] != 5) {

                    $message['shawman'][] = $bill_info['error'];
                    $status = 100;
                    $datamsg = $status . "| Shawman api error.";
                    return $datamsg;
                }
            } else {  //oracle

             
                //if ($merchant_data->CLASS_NAME == 'oracle') {  commented on 26-03-2018
          
                $model = Pms::find()->select(['SITEID', 'WSNO'])
                    ->andWhere([
                        'PROFILEID' => $merchant_id,
                        'TERMINALID' => $terminalid,
                        'UNIQUEID' => $unique_id,
                        'STATUS' => 'Y'
                    ])
                    ->one();
               // echo '<pre>';print_r($model);exit;       
                //echo '<pre>';print_r([$merchant_id,$terminalid,$unique_id,$model]);exit;

                if (!empty($model['SITEID']) && !empty($model['WSNO'])) {

                    $posdata = PosOrders::find()->select(['POS_ORDER_ID', 'ORDER_ID'])->andWhere([
                        'SITEID' => $model->SITEID,
                        'WSNO' => $model->WSNO,
                    ])
                        ->orderBy('POS_ORDER_ID DESC')
                        ->asArray(true)
                        ->one();

                    $posorderid = $posdata['POS_ORDER_ID'];

                    $psmodel = PosOrders::findOne($posorderid);
                    $psmodel->MERCHANT_ID = $merchant_id;
                    $psmodel->UNIQUE_ID = $unique_id;
                    $psmodel->CUSTOM_VAR = $merchant_id . '::' . $unique_id;
                    $psmodel->save();

                    $transactionTblData = Transactions::find()->select(['TXN_ID', 'SEQUENCENO'])->andWhere(['SEQUENCENO' => $posdata['ORDER_ID']])->one();

                    $TXN_ID = $transactionTblData['TXN_ID'];

                    $transactionModl = Transactions::findOne($TXN_ID);
                    $transactionModl->MERCHANTID = $merchant_id;
                    $transactionModl->UNIQUEID = $unique_id;
                    $transactionModl->save();

                }
                // }    commented on 26-03-2018

            }

//updates ends here
            //$merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID'=>$merchant_id])->one();
  
            if (!empty($merchant_data)) {
                if ($merchant_data->IS_SANDBOX == 'N') {

                    if ($merchant_data->IS_ORACLE == 'Y') {

                        $model = PosOrders::find()
                            ->select(['POS_ORDER_ID','ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE'])
                            ->andWhere([
                                'UNIQUE_ID' => $unique_id,
                                'MERCHANT_ID' => $merchant_id,
                                'IS_DECLINED' => 'N'
                            ])
                            ->andWhere(['<>', 'POS_MODE', '20'])
                            ->orderBy('POS_ORDER_ID DESC')
                            ->asArray(true)
                            ->one();

                    } else {

                        $model = PosOrders::find()
                            ->select(['POS_ORDER_ID','ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'ORIGINALRRN', 'AUTHCODE', 'INVOICENO', 'SURCHARGE'])
                            ->andWhere([
                                //    'UNIQUE_ID' => $unique_id,
                                'UNIQUE_ID' => \Yii::$app->request->post('uniqueid'),
                                'MERCHANT_ID' => $merchant_id,
                                'IS_DECLINED' => 'N'
                            ])
                            ->orderBy('POS_ORDER_ID DESC')
                            ->asArray(true)
                            ->one();
                      
                    }

                   
                    if (!empty($model)) {

                        $posmodel = Pos::find()
                            ->andWhere(['MERCHANTID' => $model['MERCHANT_ID'], 'TRANSACTIONID' => $model['ORDER_ID']])
                            ->one();

                        // if(empty($posmodel))    old code 14-11-2017
                        if (empty($posmodel) || $merchant_data->IS_ORACLE == 'Y' || $merchant_data->CLASS_NAME == 'SHAWMAN') {

                            $status = 200;
                           // $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                             $amount = bcdiv($model['AMOUNT'], 1, 2);
                            $surcharge = $model['SURCHARGE'];
                            // $message['mercid'] = $model['MERCHANT_ID'];
                            $message['mercid'] = $mid;
                            $message['uniqueid'] = $model['UNIQUE_ID'];

                            if ($merchant_data->IS_SURCHARGE_APPLY == 'Y') {
                                $message['amount'] = $amount + $surcharge;
                            } else {
                                $message['amount'] = $amount;
                            }

                            $message['orderid'] = $model['ORDER_ID'];
                            $message['mobileno'] = $model['MOBILE_NO'];
                            $message['customvar'] = str_replace('|', '_', $model['CUSTOM_VAR']);
                            if ($model['POS_MODE'] < 10) {
                                $message['posmode'] = '0' . $model['POS_MODE'];
                            } else {
                                $message['posmode'] = $model['POS_MODE'];
                            }
                            $message['invoiceno'] = $model['INVOICENO'];

                            

                            if ($model['POS_MODE'] == 2) {

                                error_log('POS Mode Found', 0);

                                if ($merchant_id < 10) {

                                    $merchant_id = str_replace('0', '', $merchant_id);
                                }
                                error_log('Finding rrn from transaction table', 0);

                                // $transactiondata = Transactions::find()
                                // ->select(['ORIGINALRRN'])
                                // ->andWhere([
                                //     'UNIQUEID' => $unique_id,
                                //     'MERCHANTID' => $merchant_id,
                                //     'TRANS_TYPE' => '08'//08 for transaction type void
                                // ])
                                // ->orderBy('TXN_ID DESC')
                                // ->asArray(true)
                                // ->one();

                                // $originalrrn = $transactiondata['ORIGINALRRN'];
                                $originalrrn = $model['ORIGINALRRN'];

                                $postransactiondata = Pos::find()
                                    ->select(['TRANSACTIONID', 'INVOICE_NO'])
                                    ->andWhere([
                                        'MERCHANTID' => $merchant_id,
                                        'RRN' => $originalrrn
                                    ])
                                    ->orderBy('POS_ID DESC')
                                    ->asArray(true)
                                    ->one();


                                //this code
                                if (empty($postransactiondata)) {
                                    $sequenceno = $model['ORDER_ID'];
                                    $invoiceno = $model['INVOICENO'];
                                } else {
                                    $sequenceno = $model['ORDER_ID'];
                                    $invoiceno = $postransactiondata['INVOICE_NO'];
                                }

                                //remove this code if want same txn id on void ipn response 9-3-2018

                                // $sequenceno = $model['ORDER_ID'];
                                // $invoiceno  = $model['INVOICE_NO'];

                                if ($merchant_data->IS_ORACLE == 'Y') {
                                    $invoiceno = $postransactiondata['INVOICE_NO'];
                                }


                                $model = PosOrders::find()
                                    ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'INVOICENO'])
                                    ->andWhere([
                                        'ORDER_ID' => $sequenceno,
                                    ])
                                    ->orderBy('POS_ORDER_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $status = 200;
                                //$amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                                $amount = bcdiv($model['AMOUNT'], 1, 2);
                                // $message['mercid'] = $model['MERCHANT_ID'];
                                $message['mercid'] = $mid;
                                $message['uniqueid'] = $model['UNIQUE_ID'];
                                $message['amount'] = $amount;
                                $message['orderid'] = $model['ORDER_ID'];
                                $message['mobileno'] = $model['MOBILE_NO'];
                                $message['customvar'] = $model['CUSTOM_VAR'];
                                //  $message['customvar'] = $model['CUSTOM_VAR'];
                                $message['posmode'] = '02';
                                $message['invoiceno'] = $invoiceno;

                                // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode | invoice number

                                if ($model['INVOICENO']) {

                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $model['INVOICENO'];

                                } else {

                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $message['invoiceno'];
                                }

                            } else if ($model['POS_MODE'] == 9) {
                                $orderId = $model['ORDER_ID'];
                                $message['mercid'] = $mid;
                                $transactiondata = Transactions::find()
                                    ->select(['OTHER_AMOUNT'])
                                    ->andWhere([
                                        'SEQUENCENO' => $orderId,
                                    ])
                                    ->orderBy('TXN_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $other_amount = $transactiondata['OTHER_AMOUNT'];
                                $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "||" . $other_amount;
                            } else if ($model['POS_MODE'] == 10) {
                                $message['mercid'] = $mid;
                                // $posdata = Pos::find()
                                // ->andWhere(['MERCHANTID'=>$model['MERCHANT_ID'],'TERMINALID' => $terminalid , 'TRANSACTIONTYPE'=> '310'])
                                // ->orderBy('POS_ID DESC')
                                // ->one();
                                echo '<pre>';print_r($model);exit;
                                if ($model['AUTHCODE']) {

                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|||" . trim($model['AUTHCODE']);

                                } else {

                                    $posdata = Pos::find()
                                        ->andWhere(['MERCHANTID' => trim($model['MERCHANT_ID']), 'TERMINALID' => $terminalid, 'TRANSACTIONTYPE' => '310', 'RRN' => trim($model['ORIGINALRRN'])])
                                        ->orderBy('POS_ID DESC')
                                        ->one();
                                   echo '<pre>';print_r($model);exit;
                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|||" . $posdata['AUTHCODE'];

                                }


                            } else if ($model['POS_MODE'] == 11) {
                                // echo 'hi';exit;
                                error_log('POS Mode Found', 0);
                                $amt = $model['AMOUNT'];
                                if ($merchant_id < 10) {

                                    $merchant_id = str_replace('0', '', $merchant_id);
                                }
                                error_log('Finding rrn from transaction table', 0);

                                $originalrrn = $model['ORIGINALRRN'];
                                // echo $originalrrn;exit;
                                $postransactiondata = Pos::find()
                                    ->select(['TRANSACTIONID', 'INVOICE_NO'])
                                    ->andWhere([
                                        'MERCHANTID' => $merchant_id,
                                        'RRN' => $originalrrn
                                    ])
                                    ->orderBy('POS_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $sequenceno = $postransactiondata['TRANSACTIONID'];
                                $invoiceno = $postransactiondata['INVOICE_NO'];

                                if (empty($postransactiondata)) {
                                    $sequenceno = $model['ORDER_ID'];
                                    $invoiceno = $model['INVOICE_NO'];
                                } else {
                                    $sequenceno = $postransactiondata['TRANSACTIONID'];
                                    $invoiceno = $postransactiondata['INVOICE_NO'];
                                }

                                $model = PosOrders::find()
                                    ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'INVOICENO'])
                                    ->andWhere([
                                        'ORDER_ID' => $sequenceno,
                                    ])
                                    ->orderBy('POS_ORDER_ID DESC')
                                    ->asArray(true)
                                    ->one();

                                $status = 200;
                                $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                                // $message['mercid'] = $model['MERCHANT_ID'];
                                $message['mercid'] = $mid;
                                $message['uniqueid'] = $model['UNIQUE_ID'];
                                $message['amount'] = $amount;
                                $message['orderid'] = $model['ORDER_ID'];
                                $message['mobileno'] = $model['MOBILE_NO'];
                                $message['customvar'] = $model['CUSTOM_VAR'];
                                $message['customvar'] = $model['CUSTOM_VAR'];
                                $message['posmode'] = '02';
                                //$message['invoiceno'] = $invoiceno;
                                $message['invoiceno'] = $invoiceno;

                                // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode | invoice number
                                //$message['invoiceno'] = '000012';
                                $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'] . "|" . $message['invoiceno'];

                            } else {

                                // datamsg - status | uniqueid | merchant id | amount | order id | mobile number | custom var | pos mode

                                if (empty($message['posmode'])) { // for pnb transaction
                                    $message['mercid'] = $mid;
                                    // $datamsg = $status."||".$message['uniqueid']."|".$message['mercid']."|".$message['amount']."|".$message['orderid']."|".$message['mobileno']."|".$message['customvar'];  //old code
                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . '|01';
                                } else { // for oracle transaction
                                    $message['mercid'] = $mid;
                                    $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'] . "|" . $message['posmode'];
                                }


                            }

                        } else {
                            $message['orderid'][] = "No New record.";
                            $datamsg = $status . "| No New record.";
                        }
                    } else {
                        $message['orderid'][] = "No Record exist.";
                        $datamsg = $status . "| No Record exist.";
                    }
                } else {
                    $model = PnbTransaction::find()
                        ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR'])
                        ->andWhere([
                            'UNIQUE_ID' => $unique_id,
                            'MERCHANT_ID' => $merchant_id,
                        ])
                        ->orderBy('PNB_TRANSACTION_ID DESC')
                        ->asArray(true)
                        ->one();


                    if (!empty($model)) {
                        $status = 200;
                        $amount = number_format(floor($model['AMOUNT'] * 100) / 100, 2, '.', '');
                        $message['mercid'] = $model['MERCHANT_ID'];
                        $message['uniqueid'] = $model['UNIQUE_ID'];
                        $message['amount'] = $amount;
                        $message['orderid'] = $model['ORDER_ID'];
                        $message['mobileno'] = $model['MOBILE_NO'];
                        $message['customvar'] = $model['CUSTOM_VAR'];
                        $datamsg = $status . "||" . $message['uniqueid'] . "|" . $message['mercid'] . "|" . $message['amount'] . "|" . $message['orderid'] . "|" . $message['mobileno'] . "|" . $message['customvar'];
                    } else {
                        $message['orderid'][] = "No Record exist.";
                        $datamsg = $status . "| No Record exist.";
                    }
                }
            } else {
                $message['orderid'][] = "Merchant not exist.";
                $datamsg = $status . "| Merchant not exist.";
            }
        }
    
    // echo '<pre>';print_r($datamsg);exit;
    \Yii::info('response end to pos devices : ' . $datamsg, 'soapinfo');
        //return ['status' => $status, 'message' => $message];
        return $datamsg;
    }

    public function actionTransactionResponse()
    {
        $status = 502;
        $message = [];

        $order_id = \Yii::$app->request->post('orderid');
        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');

        $post[] = [
            'orderid' => $order_id,
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
        ];
        \Yii::info('model TransactionResponse Data : ' . json_encode($post), 'soapinfo');

        if (empty($order_id)) {
            $message['ORDER_ID'][] = "Order  ID cannot be blank.";
            $status = 112;
        }

        if (empty($merchant_id)) {
            $message['MERCHANT_ID'][] = "Merchant  ID cannot be blank.";
            $status = 100;
        }

        if (empty($unique_id)) {
            $message['UNIQUE_ID'][] = "Unique  ID cannot be blank.";
            $status = 114;
        }

        if (!empty($order_id) && !empty($merchant_id) && !empty($unique_id)) {
            $merchant_id =(int) $merchant_id;
            $model = PosOrders::find()
                ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'IS_DECLINED', 'SURCHARGE'])
                ->andWhere([
                    'ORDER_ID' => $order_id,
                    'MERCHANT_ID' => $merchant_id,
                    'UNIQUE_ID' => $unique_id,
                ])
                ->orderBy('POS_ORDER_ID DESC')
                ->asArray(true)
                ->one();

            if ($model['IS_DECLINED'] == 'Y') {
                //return ['status' => '301', 'message' => 'Transaction declined.'];
            }

            if (!empty($model)) {
                //var_dump($model['ORDER_ID']);
                //exit();
                $transaction_model = Pos::find()
                    ->select([
                        'TRANSACTIONID',
                        'APTRANSACTIONID',
                        'INVOICE_NO',
                        'MERCHANTID',
                        'TERMINALID',
                        'CARDISSUER',
                        'CHMOD',
                        'AMOUNT',
                        'CURRENCYCODE',
                        'TRANSACTIONSTATUS',
                        'MESSAGE',
                        'RRN',
                        'AUTHCODE',
                        'CUSTOMER',
                        'CUSTOMERPHONE',
                        'CARD_NUMBER',
                        'CUSTOMEREMAIL',
                        'TRANSACTIONTYPE',
                        'ISRISK',
                        'IPNID',
                        'ap_SecureHash',
                        'TOKEN',
                        'CARDUNIQUECODE'
                    ])
                    ->andWhere([
                        'MERCHANTID' => $merchant_id,
                        'TRANSACTIONID' => $order_id,
                        //'TRANSACTIONID' => $model['ORDER_ID'],
                    ])->orderBy('POS_ID DESC')->asArray(true)->one();
                // ])->asArray(true)->one(); older code

                if (!empty($transaction_model)) {
                    $transaction_model['SURCHARGE'] = $model['SURCHARGE'];
                    //$transaction_model['BASE_AMOUNT'] = ($transaction_model['AMOUNT'] - $model['SURCHARGE']);
                    $status = 200;
                    $message = $transaction_model;
                } else {
                    $message['ORDER_ID'][] = "Transaction details is not available, Please try after some time.";
                }

            } else {
                $message['ORDER_ID'][] = "Order  does not exist.";
                if ($model->IS_DECLINED == 'Y') {
                    $status = '301';
                    $message = 'Txn cancelled';
                }
            }
        }

        return ['status' => $status, 'message' => $message];
    }


    public function actionTransactionResponsetest()
    {
        $status = 502;
        $message = [];

        $order_id = \Yii::$app->request->post('orderid');
        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');

        $post[] = [
            'orderid' => $order_id,
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
        ];
        \Yii::info('model TransactionResponse Data : ' . json_encode($post), 'soapinfo');

        if (empty($order_id)) {
            $message['ORDER_ID'][] = "Order  ID cannot be blank.";
            $status = 112;
        }

        if (empty($merchant_id)) {
            $message['MERCHANT_ID'][] = "Merchant  ID cannot be blank.";
            $status = 100;
        }

        if (empty($unique_id)) {
            $message['UNIQUE_ID'][] = "Unique  ID cannot be blank.";
            $status = 114;
        }

        if (!empty($order_id) && !empty($merchant_id) && !empty($unique_id)) {
            $model = PosOrders::find()
                ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'IS_DECLINED'])
                ->andWhere([
                    'ORDER_ID' => $order_id,
                    'MERCHANT_ID' => $merchant_id,
                    'UNIQUE_ID' => $unique_id,
                ])
                ->orderBy('POS_ORDER_ID DESC')
                ->asArray(true)
                ->one();

            if ($model->IS_DECLINED == 'Y') {
               // return ['status' => '301', 'message' => 'Transaction declined.'];
            }

            if (!empty($model)) {
                //var_dump($model['ORDER_ID']);
                //exit();
                $transaction_model = Pos::find()
                    ->select([
                        'TRANSACTIONID',
                        'APTRANSACTIONID',
                        'INVOICE_NO',
                        'MERCHANTID',
                        'TERMINALID',
                        'CARDISSUER',
                        'CHMOD',
                        'AMOUNT',
                        'CURRENCYCODE',
                        'TRANSACTIONSTATUS',
                        'MESSAGE',
                        'RRN',
                        'AUTHCODE',
                        'CUSTOMER',
                        'CUSTOMERPHONE',
                        'CARD_NUMBER',
                        'CUSTOMEREMAIL',
                        'TRANSACTIONTYPE',
                        'ISRISK',
                        'IPNID',
                        'ap_SecureHash',
                    ])
                    ->andWhere([
                        'MERCHANTID' => $merchant_id,
                        'TRANSACTIONID' => $order_id,
                        //'TRANSACTIONID' => $model['ORDER_ID'],
                    ])->orderBy('POS_ID DESC')->asArray(true)->one();
                // ])->asArray(true)->one(); older code

                if (!empty($transaction_model)) {
                    $status = 200;
                    $message = $transaction_model;
                } else {
                    $message['ORDER_ID'][] = "IPN details does not exist.";
                }

            } else {
                $message['ORDER_ID'][] = "Order  does not exist.";
            }
        }


        return ['status' => $status, 'message' => $message];
    }

    public function actionTransactionCustomvar()
    {
        $status = 502;
        $message = [];
        $data = \Yii::$app->request->post('data');

        //\Yii::info('model posorder for details from portal : '.json_encode($data), 'soapinfo');
        // echo "<pre>"; var_dump($data); exit;
        $data = json_decode($data); //exit;

        if (!empty($data)) {
            foreach ($data as $key => $row) {

                $terminalid = $row->terminalid;
                $merchant_id = $row->mercid;
                $order_id = $row->orderid;
                $model = PosOrders::find()
                    ->select(['CUSTOM_VAR', 'MERCHANT_ID', 'ORDER_ID'])
                    ->andWhere([
                        'ORDER_ID' => $order_id,
                        'MERCHANT_ID' => $merchant_id,
                    ])
                    //->orderBy('POS_ORDER_ID DESC')
                    ->asArray(true)
                    ->one();

                if (!empty($model)) {

                    $status = 200;
                    //$amount  = number_format(floor($model['AMOUNT']*100)/100,2, '.', '');
                    $message[$model['ORDER_ID']]['status'] = $status;
                    $message[$model['ORDER_ID']]['merchantid'] = $model['MERCHANT_ID'];
                    $message[$model['ORDER_ID']]['orderid'] = $model['ORDER_ID'];
                    $message[$model['ORDER_ID']]['customvar'] = $model['CUSTOM_VAR'];

                } else {
                    $status = 100;
                    $message[$order_id]['status'] = $status;
                    $message[$order_id]['orderid'] = $order_id;
                    $message[$order_id]['message'] = "No Record exist.";

                }
                //$datamsg = json_encode($message);
            }

        }
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        // $arr = json_encode($message);
        //$arr1 = array('data1' => $arr);
        //echo "<pre>"; var_dump(json_encode($message)); exit;


        //return $datamsg = "data1={$arr}";

        return $datamsg = $message;

    }

    public function actionTestindex()
    {
         $postdata['Pos'] = [];
        \Yii::info('data from pos for transaction id : ' . $_POST['TRANSACTIONID'], 'soapinfo');
        \Yii::info('data from pos : ' . json_encode($_POST), 'soapinfo');
       
        //echo "<pre>"; var_dump($_POST); die("here");
         $_POST['Pos'] = [
            'TRANSACTIONID'     => 1536752622,
             'APTRANSACTIONID'  => 6675427,
             //MERCHANTID'       => "19122",
             'MERCHANTID'       => "24228",
             'TERMINALID'       => 33346150,
             'CARDISSUER'       => "Visa",
             'CHMOD'            => 'pos',
             'AMOUNT'           => "1.08",
             'CURRENCYCODE'     => "356",
             'TRANSACTIONSTATUS' => "200",
             'MESSAGE'           => "Successful",
             'RRN'               => "825517928566",
             'AUTHCODE'          => "003046",
             'CUSTOMER'          => "AJAY SHARMA",
             'CUSTOMERPHONE'     => "1245789865",
             'CARD_NUMER'        => '479932xxxxx9299',
             'CUSTOMEREMAIL'     => "test@test.com",
             'TRANSACTIONTYPE'   => "320",
             'ISRISK'            => "0",
             'IPNID'             => "2700469",
             'ap_SecureHash'     => "469760508",
          

         ];
        $model = new Pos();
        $postdata['Pos'] = $_POST;
        \Yii::info('data from postdata : ' . json_encode($postdata), 'soapinfo');

        $TRANSACTIONID = $postdata['Pos']['TRANSACTIONID'];

        // code starts here for shawman bill settlement


        $MID = $postdata['Pos']['MERCHANTID'];
        $TID = $postdata['Pos']['TERMINALID'];
        $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $MID])->one();

        if(!empty($merchant_data->REDIRECT_URL)){
            if($MID == '22723'){
                $data = json_encode($postdata['Pos']);
            }else{
                $data = $postdata['Pos'];
            }
            $res = $this->sendDataOverPosttest($merchant_data->REDIRECT_URL, $data,'POST');
              echo '<pre>';print_r($res);exit;
        }
    echo 'hello';exit;
        //echo $MID.' '.$TID;exit;
        if ($merchant_data->CLASS_NAME == 'SHAWMAN') {

            $posorder = PosOrders::find()
                ->select(['ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'REFERENCEID', 'SHAWMAN_TYPE'])
                ->andWhere([
                    'ORDER_ID' => $TRANSACTIONID,
                ])
                ->orderBy('POS_ORDER_ID DESC')
                ->asArray(true)
                ->one();

            if ($posorder['REFERENCEID']) {

                $shawmanHelper = new shawmanHelper();
                $pms_data = Pms::find()->where(['PROFILEID' => $MID])->andWhere(['TERMINALID' => $TID])->one();
                //echo '<pre>';print_r($pms_data);exit;
                $TransactionId = $postdata['Pos']['TRANSACTIONID'];

                //$billfor  =  substr($TransactionId,1);
                // $source   =  substr($TransactionId,0,1);
                // $SourceId =  $source;

                $RestaurantId = $pms_data->UNIQUEID;
                $BillFor = $TransactionId;
                // $SourceId = $SourceId ;
                $SourceId = $posorder['SHAWMAN_TYPE'];
                $DeviceId = $TID;
                $BillAmount = $postdata['Pos']['AMOUNT'];
                //  $BillAmount = $posorder['AMOUNT'];

                //code written by jayesh
                if ($posorder['AMOUNT'] < $BillAmount) {
                    $TipAmount = $BillAmount - $posorder['AMOUNT'];
                } else {
                    $TipAmount = '0.00';
                }
                \Yii::info('tip amount is : ' . $TipAmount, 'soapinfo');
                //code written by jayesh

                $TransactionStatus = $postdata['Pos']['TRANSACTIONSTATUS'];
                $AuthCode = $postdata['Pos']['AUTHCODE'];
                $RRN = $postdata['Pos']['RRN'];
                $CreditCardNo = '1009';//substr($postdata['Pos']['CARD_NUMER'],12);
                $CustomerName = $postdata['Pos']['CUSTOMER'];
                $ChargeSlipNo = '';
                $Remark = '';

                if (!is_numeric($TransactionId)) {

                    $bill_settlement = @$shawmanHelper->settleBill($RestaurantId, $BillFor, $SourceId, $DeviceId, $posorder['AMOUNT'], $TipAmount, $TransactionId, $TransactionStatus, $AuthCode, $RRN, $CreditCardNo, $CustomerName, $ChargeSlipNo, $Remark);
                    \Yii::info('showman response : ' . json_encode($bill_settlement), 'soapinfo');
                    //echo '<pre>';print_r($bill_settlement);exit;
                }
            }
            //echo '<pre>';print_r($bill_settlement);exit;
        }


        // code ends here


        //var_dump($model->load($_POST)); exit;
        // if(!empty($_POST) && $model->load(Yii::$app->request->post())) {

        @$postdata['Pos']['MERCHANTID'] = (string)((int)$_POST['MERCHANTID']);
        \Yii::info('data from merchant postdata : ' . json_encode($postdata), 'soapinfo');
        if (isset($_POST['TOKEN'])) {
            $model->scenario = 'savecardtransaction';
            error_log('IPN HIT COME FOR SAVE CARD', 0);
        } else if ($_POST['TRANSACTIONTYPE'] == '370') {
            $model->scenario = 'salecompletiontransaction';
        } else {
            $model->scenario = 'normaltransaction';
        }


        if (isset($_POST['TOKEN'])) {
            $hash = array();
            $hash['TRANSACTIONID'] = $_POST['TRANSACTIONID'];
            $hash['MERCHANTID'] = $_POST['MERCHANTID'];
            $hash['TOKEN'] = $_POST['TOKEN'];
            $hash['CARDUNIQUECODE'] = $_POST['CARDUNIQUECODE'];
            $hash['TERMINALID'] = $_POST['TERMINALID'];
            $hash['CARD_NUMBER'] = $_POST['CARD_NUMBER'];
            $hash['CARD_EXPIRY'] = $_POST['CARD_EXPIRY'];
            $hash['CARD_ISSUER'] = $_POST['CARD_ISSUER'];
            $hash['CARD_TYPE'] = $_POST['CARD_TYPE'];

            $ap_SecureHash = crc32(implode('~', $hash));

            if ($_POST['ap_SecureHash'] != $ap_SecureHash) {
                \Yii::info('secure hash mismatch : ' . json_encode($postdata['Pos']), 'soapinfo');
                $response = array(
                    'status' => '400',
                    'msg' => 'secure hash mismatch ' . $ap_SecureHash
                );
                \Yii::info('model errors pos : ' . json_encode($response), 'soapinfo');
                echo json_encode($response);
                exit;

            }
        }

        // $postdata['TRANSACTIONID'] = $_POST['TRANSACTIONID'];
        if (!empty($postdata)) {
            if ($model->load($postdata)) {
                //echo '<pre>';print_r($postdata);exit;
                if(isset($postdata['Pos']['CARD_ISSUER'])){
                    $model->CARDISSUER = $postdata['Pos']['CARD_ISSUER'];
                }
                if ($model->save()) {

                    error_log('IPN DATA SAVED TO DB', 0);
                    $connection = \Yii::$app->db;

                    if (empty($TipAmount)) {
                        $TipAmount = 0;
                    }

                    \Yii::info("UPDATE tbl_pos_orders SET TIP_AMOUNT = $TipAmount, IS_SUCCESSFUL='Y'  WHERE ORDER_ID='" . $TRANSACTIONID . "'", 'soapinfo');
                    if (!isset($_POST['TOKEN'])) {
                        $connection->createCommand("UPDATE tbl_pos_orders SET TIP_AMOUNT = $TipAmount, IS_SUCCESSFUL='Y'  WHERE ORDER_ID='" . $TRANSACTIONID . "'")->execute();
                    }


                    \Yii::info('model save pos data : ' . json_encode($postdata['Pos']), 'soapinfo');
                    $merchant = Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $model->MERCHANTID])->one();

                    if ($merchant == null)
                        throw new NotFoundHttpException('The requested page does not exist.');
                   

                   echo json_encode(['status' => '200','msg' => '']);exit;
                    // if (!empty($merchant->CLASS_NAME)) {
                    //     $classname = "\\app\\helpers\\" . $merchant->CLASS_NAME;
                    //     $methodname = $merchant->METHOD_NAME;
                    //     $apih = new $classname;
                    //     $data = $apih->$methodname($model);
                    // }


                    //$apihelper = new eurekaHelper();
                    //$datasave = $apihelper->savePosData($model);

                   
                } else {
                    echo "<pre>";
                    var_dump($model->getErrors());
                    \Yii::info('model errors pos : ' . json_encode($model->getErrors()), 'soapinfo');
                    exit;
                }
            }

        }
        //return $this->render('index');
    }

    public function sendIPNtoTanishq($postdata)
    {

        $url = 'http://tanishq.nowpay.co.in/invoice/pospayment';
        $fields = $postdata;
        $method = 'POST';
        \Yii::info('send postdata to tanishq  : ' . json_encode($postdata), 'soapinfo');
        $res = $this->sendDataOverPost($url, $fields, $method,'30','80');
        \Yii::info('tanishq response : ' . json_encode($res), 'soapinfo');
    }

    // public function sendDataOverPost($url, $fields, $method)
    // {

    //     $ch = curl_init();

    //     curl_setopt($ch, CURLOPT_URL, $url);
    //     curl_setopt($ch, CURLOPT_POST, 1);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     curl_setopt($ch, CURLOPT_TIMEOUT, 120);
    //     $result = curl_exec($ch);
    //     curl_close($ch);

    //     if (curl_errno($ch)) {
    //         \Yii::info('Curl error send postdata to tanishq  : ' . json_encode(curl_error($ch)), 'soapinfo');
    //     }

    //     return $result;
    // }
    // 
    // 

    public function sendDataOverPost($url, $fields, $method, $timeout = 30, $port = 443)
    {
         $url = trim($url);
        \Yii::info('url  : ' . $url.' feilds : '.$fields.' method :'.$method, 'soapinfo');


        $ch = curl_init();
        $User_Agent = 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.43 Safari/537.31';
        $request_headers = array();
        $request_headers[] = 'User-Agent: ' . $User_Agent;
        $request_headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';

        curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
        if (strtoupper($method) == 'POST') {
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        } else {
            curl_setopt($ch, CURLOPT_URL, $url . $fields);
        }
        if ($port == 443) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }
        curl_setopt($ch, CURLOPT_PORT, $port);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        $result = curl_exec($ch);
        curl_close($ch);
     \Yii::info('Curl result  : ' . $result, 'soapinfo');
        //error_log($url.$fields,0);
        //error_log($result,0);
        return $result;
    }

public function sendDataOverPosttest($url, $fields, $method, $timeout = 30, $port = 443)
    {
        $url = trim($url);
        \Yii::info('url  : ' . $url.' feilds : '.$fields.' method :'.$method, 'soapinfo');
        $ch = curl_init();
        $User_Agent = 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.43 Safari/537.31';
        $request_headers = array();
        $request_headers[] = 'User-Agent: ' . $User_Agent;
        $request_headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';

        curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
        if (strtoupper($method) == 'POST') {
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        } else {
            curl_setopt($ch, CURLOPT_URL, $url . $fields);
        }
        if ($port == 443) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }
        curl_setopt($ch, CURLOPT_PORT, $port);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        $result = curl_exec($ch);
        if (curl_error($ch)) {
             $error_msg = curl_error($ch);
       }
        curl_close($ch);

echo '<pre>';var_dump($result);exit;
     \Yii::info('Curl result  : ' . $result, 'soapinfo');
        //error_log($url.$fields,0);
        //error_log($result,0);
        return $result;
    }

    public function actionCancelTxn()
    {


        $status = 502;
        $message = [];
        $order_id = \Yii::$app->request->post('orderid');
        $amount = \Yii::$app->request->post('amount');
        $merchant_id = \Yii::$app->request->post('mercid');
        $unique_id = \Yii::$app->request->post('uniqueid');
        $postxntype = \Yii::$app->request->post('postxntype');
        $originalrrn = \Yii::$app->request->post('originalrrn');
        $post[] = [
            'orderid' => $order_id,
            'amount' => $amount,
            'mercid' => $merchant_id,
            'uniqueid' => $unique_id,
            'postxntype' => $postxntype,
            'originalrrn' => $originalrrn,
        ];

        \Yii::info('data received from shawman to declined void : ' . json_encode($post), 'soapinfo');

        if (!empty($order_id) && !empty($amount) && !empty($merchant_id) && !empty($unique_id) && !empty($postxntype)) {
            $merchant_data = \app\models\Merchant::find()->where(['AIRPAY_MERCHANT_ID' => $merchant_id])->one();
            if (!empty($merchant_data)) {
//                 if ($postxntype == '8' || $postxntype == '08') {
//                     $postransactiondata = Pos::find()
//                         ->select(['TRANSACTIONID', 'INVOICE_NO'])
//                         ->andWhere([
//                             'MERCHANTID' => $merchant_id,
//                             'RRN' => $originalrrn,
//                         ])
//                         ->orderBy('POS_ID DESC')
//                         ->asArray(true)
//                         ->one();
//                     if (!empty($postransactiondata)) {
//                         $sequenceno = $postransactiondata['TRANSACTIONID'];
//                         $posorderdata = PosOrders::find()
//                             ->select(['POS_ORDER_ID', 'ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE','REQUEST_TIME'])
//                             ->andWhere([
//                                 'ORDER_ID' => $sequenceno,
//                                 'POS_MODE' => '2',
//                                 'IS_SUCCESSFUL' => 'N',
//                                 'IS_DECLINED' => 'N'
//                             ])
//                             ->orderBy('POS_ORDER_ID DESC')
//                             ->asArray(true)
//                             ->one();
//                         if (!empty($posorderdata)) {
//                             $time = time();
//                             $ordertime = $posorderdata['REQUEST_TIME'];

//                            // if ($time > ($ordertime + 300)) {
//                                 $connection = \Yii::$app->db;
//                                 $result = $connection->createCommand("UPDATE tbl_pos_orders SET  IS_DECLINED = 'Y' WHERE POS_ORDER_ID ='" . $posorderdata['POS_ORDER_ID'] . "'")->execute();
//                                 if ($result) {
//                                     $status = 200;
//                                     $response = array('status' => $status, 'message' => $message);
//                                 } else {
//                                     $message['order_id'] = 'Void request already declined.';
//                                     $response = array('status' => $status, 'message' => $message);
//                                 }
//                             // } else {
//                             //     $message['order_id'] = 'Cannot decline this Void request now, you can try after 5 minutes.';
//                             //     $response = array('status' => $status, 'message' => $message);
//                             // }
//                         } else {
//                             $message['order_id'] = 'Cannot decline this void request.';
//                             $response = array('status' => $status, 'message' => $message);
//                         }
//                     } else {
//                         $message['order_id'] = 'Cannot decline this void request.';
//                         $response = array('status' => $status, 'message' => $message);
//                     }


//                 } else
                if ($postxntype == '1' || $postxntype == '01' || $postxntype == '7' || $postxntype == '07' || $postxntype == '10' ||  $postxntype == '8' ||  $postxntype == '08') {
                
                    if($postxntype == '8' ||  $postxntype == '08'){
                       $postxntype = '2';
                    }
                    $posorderdata = PosOrders::find()
                        ->select(['POS_ORDER_ID', 'ORDER_ID', 'MERCHANT_ID', 'AMOUNT', 'UNIQUE_ID', 'MOBILE_NO', 'CUSTOM_VAR', 'POS_MODE', 'CREATED_ON', 'REQUEST_TIME'])
                        ->andWhere([
                            'ORDER_ID' => $order_id,
                            'MERCHANT_ID' => $merchant_id,
                            'AMOUNT' => $amount,
                            'POS_MODE' => $postxntype,
                            'IS_SUCCESSFUL' => 'N',
                             'IS_DECLINED' => 'N'
                        ])
                        ->orderBy('POS_ORDER_ID DESC')
                        ->asArray(true)
                        ->one();
               
                    //echo '<pre>';print_r($posorderdata);exit;
                    if (!empty($posorderdata)) {
                        //var_dump($posorderdata);exit;
                        $time = time();
                        $ordertime = $posorderdata['REQUEST_TIME'];

                       // if ($time > ($ordertime + 300)) {
                            $connection = \Yii::$app->db;
                            $result = $connection->createCommand("UPDATE tbl_pos_orders SET  IS_DECLINED = 'Y' WHERE ORDER_ID ='" . $posorderdata['ORDER_ID'] . "'")->execute();
                            if ($result) {
                                $status = 200;
                                $response = array('status' => $status, 'message' => $message);
                            } else {
                                $message['order_id'] = 'Request is already declined.';
                                $response = array('status' => $status, 'message' => $message);
                            }
                        // } else {
                        //     $message['order_id'] = 'Cannot decline this Sale request now, you can try after 5 minutes.';
                        //     $response = array('status' => $status, 'message' => $message);
                        // }
                    } else {
                        $message['order_id'] = 'Cannot decline this Request.';
                        $response = array('status' => $status, 'message' => $message);
                    }

                } else {
                    $message['postxntype'] = 'Pos Transaction Type is not valid.';
                    $response = array('status' => $status, 'message' => $message);
                }
            } else {
                $message['merchant_id'] = 'Merchant Id does not exist.';
                $response = array('status' => $status, 'message' => $message);
            }
        } else {
            if (empty($order_id)) {
                $message['order_id'] = 'Order Id is empty.';
            }
            if (empty($amount)) {
                $message['amount'] = 'Amount is empty.';
            }
            if (empty($unique_id)) {
                $message['unique_id'] = 'Unique Id is empty.';
            }
            if (empty($postxntype)) {
                $message['postxntype'] = 'Pos Transaction Type is empty.';
            }
            if (empty($originalrrn)) {
                $message['originalrrn'] = 'Original RRN is empty.';
            }
            if (empty($merchant_id)) {
                $message['merchant_id'] = 'Merchant Id is empty.';
            }
            $response = array('status' => $status, 'message' => $message);
        }
        return json_encode($response);
    }

    public function actionCanceltransaction()
    {

        $connection = \Yii::$app->db;
        $result = $connection->createCommand("UPDATE tbl_pos_orders SET  IS_DECLINED = 'Y' WHERE ORDER_ID ='" . $_GET['orderid'] . "'")->execute();

        $this->redirect('http://tanishq.nowpay.co.in/site/login');

    }

    public function actionCanceltransactionnowpay()
    {

        $connection = \Yii::$app->db;
        $result = $connection->createCommand("UPDATE tbl_pos_orders SET  IS_DECLINED = 'Y' WHERE ORDER_ID ='" . $_GET['orderid'] . "'")->execute();

        $url = \Yii::$app->request->referrer;

        $url = str_replace("process.php", "", $url);

        $this->redirect($url);

    }

    public function actionCanceltransactionschoolpay()
    {

        $connection = \Yii::$app->db;
        $result = $connection->createCommand("UPDATE tbl_pos_orders SET  IS_DECLINED = 'Y' WHERE ORDER_ID ='" . $_GET['orderid'] . "'")->execute();

        $url = \Yii::$app->request->referrer;

        $url = str_replace("sendtoairpay.php", "form.php", $url);

        $this->redirect($url);

    }

    public function actionExpiretxn()
    {

        $time = time() - 7200;
        \Yii::$app->db->createCommand('update tbl_pos_orders set IS_DECLINED = "Y" where CREATED_ON < ' . $time)->execute();
    }


    public function actionCalcamt($method, $amount, $charges)
    {

        $taxRate = 0.18;

        if ($method == "cc") {
            $calculatedAmount = ($charges * $amount) / 100;
            $b_chgs = $calculatedAmount * $taxRate;
            $tot_amt = $calculatedAmount + $b_chgs;
        }

        if ($method == "dc") {
            if ($amount > 2000) {
                $calculatedAmount = ($charges * $amount) / 100;
                $b_chgs = $calculatedAmount * $taxRate;
                $tot_amt = $calculatedAmount + $b_chgs;
            }
        }

        if ($method == "amex") {
            $calculatedAmount = ($charges * $amount) / 100;
            $b_chgs = $calculatedAmount * $taxRate;
            $tot_amt = $calculatedAmount + $b_chgs;
        }

        if ($method == "icc") {
            $calculatedAmount = ($charges * $amount) / 100;
            $b_chgs = $calculatedAmount * $taxRate;
            $tot_amt = $calculatedAmount + $b_chgs;
        }

        return $tot_amt;
    }

    public function actionCalcamthigher($amount, $charges)
    {
        $taxRate = 0.18;

        $calculatedAmount = ($charges * $amount) / 100;
        $b_chgs = $calculatedAmount * $taxRate;
        $tot_amt = $calculatedAmount + $b_chgs;
       
        return $tot_amt;
    }

}
