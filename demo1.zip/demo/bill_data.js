const async = require('async');
const mysql = require('mysql');
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'partnerpay'
});
mc.connect();
module.exports.api_authentication = function (test, callback) {
    mc.query("SELECT TOKEN,USER_ID FROM api_user WHERE MERCID = '" + test.merchantid + "'", function (error, results, fields) {
        if (error) {
            return callback(false);
        } else if (results.length == 0) {
            return callback(" ");
        } else {
            console.log(results[0])
            return callback(results[0]);
            // module.export. false;
        }
    });
}

module.exports.add_bill = function (bill_data, callback) {
    mc.query("Select FIELDS,VALIDATIONS from tbl_provider where provider_id = '" + bill_data.data.providerid + "'", function (error, results, fields) {
        if (error) {
            return callback(false);
        } else {
            fields = results[0]['FIELDS'].split('|');
            validation = results[0]['VALIDATIONS'].split('::');
            console.log(fields);
            if (bill_data.data.servicetype == 0) {
                register(bill_data,function(status){
                    console.log(status);
                    if(status){
                        insert_bill(bill_data,'y',function (bill_status){
                            console.log(bill_status);
                            if(bill_status){
                                return callback(bill_status);
                            }else{
                                return callback(false);
                            }
                        });
                    }else{
                        return callback(false);
                    }
                });
            } else {
                insert_bill(bill_data,'y',function (bill_status){
                            console.log(bill_status);
                            if(bill_status){
                                return callback(bill_status);
                            }else{
                                return callback(false);
                            }
                        });
            }
        }
    });//   return callback(false,bill_data);
}

module.exports.validate = function (billdetails, callback) {
    mc.query("Select FIELDS,VALIDATIONS from tbl_provider where provider_id = '" + billdetails.providerid + "'", function (error, results, fields) {
        if (error) {
            console.log(error);
            return callback(false);
        } else if (results.length == 0) {
            console.log(results.length);
            return callback(false);
        } else {
            var fields = results[0]['FIELDS'].split('|');
            var validation = results[0]['VALIDATIONS'].split('::');
            for (var key in billdetails.billdata) {
                if (/^[A-Za-z\s]{1,50}$/.test(billdetails.billdata[key]['firstname']) && /^[A-Za-z\s]{1,50}$/.test(billdetails.billdata[key]['lastname']) && /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(billdetails.billdata[key]['email'])) {
                    // console.log('in');
                    for (var keys in fields) {
                        var validate = new RegExp(validation[keys]);
                        field_name = fields[keys].replace(" ", "_");
                        if (validate.test(billdetails.billdata[key]['details'][field_name])) {
                            continue;
                        } else {
                            // console.log('inside');
                            return callback(false);
                        }
                    }
                } else {
                    // console.log('out');
                    return callback(false);
                }
            }
            return callback(true);
        }
    });
}


function register(bill_data, callback) {
    async.forEachOf(bill_data.data.billdata,function (value, key, call) {
                mc.query("Select ID from tbl_registered_account where ACCOUNT_NO = '" + bill_data.data.billdata[key]['mobile'] + "'", function (error, results, fields) {
                if (error) {
                    return callback(false);
                } else if (results.length == 0) {
                    console.log(key);
                    mc.query("Insert into tbl_registered_account (UTILITY_ID,PROVIDE_ID,ACCOUNT_NO) VALUES('" + bill_data.data.utilityid + "','" + bill_data.data.providerid + "','" + bill_data.data.billdata[key]['mobile'] + "')", function (error, results, fields) {
                        if (error) {
                            return callback(false);
                        }else{
                            call();
                        }
                    });
                }else{
                    call();
                }
            });
            
    }, function (err) {
        if (!err) return callback(true);
    });
}

function insert_bill(bill_data, register,callback) {
    async.forEachOf(bill_data.data.billdata,function (value, key, call) {
                mc.query("Select PROVIDER_BILL_DETAILS_ID from tbl_provider_bill_details where ACCOUNT_NO = '" + bill_data.data.billdata[key]['mobile'] + "' AND AMOUNT =0 ", function (error, results, fields) {
                if (error) {
                    return callback(false);
                } else if (results.length == 0) {
                    console.log(key);
                    mc.query("INSERT INTO tbl_provider_bill_details (FNAME,LNAME,EMAIL,IS_REGISTER,MOBILE_NUMBER,DETAILS,ACCOUNT_NO,PROVIDER_ID,UTILITY_ID) VALUES('" + bill_data.data.billdata[key]['firstname'] + "','" + bill_data.data.billdata[key]['lastname'] + "','" + bill_data.data.billdata[key]['email'] + "','"+register+"','"+ bill_data.data.billdata[key]['mobile'] + "','" +bill_data.data.billdata[key]['details'] + "','" + bill_data.data.billdata[key]['mobile'] + "','" + bill_data.data.providerid + "','" + bill_data.data.utilityid + "')", function (error, results, fields) {
                        if (error) {
                            return callback(false);
                        }else{
                            bill_data.data.billdata[key]['refid'] = results.insertId;
                            call();
                        }
                    });
                }else{
                    bill_data.data.billdata[key]['refid'] = results[0]['PROVIDER_BILL_DETAILS_ID'];
                    call();
                }
            });
              
    }, function (err) {
        if (!err) return callback(bill_data);
    });
}