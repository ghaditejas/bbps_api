const mysql = require('mysql');
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'partnerpay'
});
mc.connect();

module.exports.get_utility = function(user_data,callback){
    var utility = {"merchantid":user_data.merchantid,"secretkey":user_data.merchantid};
    mc.query("Select * from tbl_utility order by utility_id", function (error, results, fields) {
        if (error){
            return callback(false);
        }else{
            for (var key in results) {
                utility[results[key]['utility_id']]= {'utilityname':results[key]['utility_name'],'provider':{}};
            }
            return callback(utility);
        } 
    });

}

module.exports.get_provider = function(utility,callback){
    mc.query("Select * from tbl_provider order by utility_id", function (error, results, fields) {
        if (error){
            return callback(false);
        }else{
         for (var key in results) {
            utility[results[key]['utility_id']]['provider'][results[key]['provider_id']] = {
                'providername':results[key]['provider_name'],
                'data':{
                '0':{'instantflag':1,
                'fieldname':results[key]['INSTANT_FIELDS'],
                'validataion':results[key]['INSTANT_VALIDATION'],
                },
                '1':{'recharge':1,
                'fieldname':results[key]['RECHARGE_FIELDS'],
                'validataion':results[key]['RECHARGE_VALIDATION'],
                },
                '2':{'registrationflag':0,
                'fieldname':results[key]['FIELDS'],
                'validataion':results[key]['VALIDATION'],
                },
                },
                'biller_master_id':results[key]['BILLER_MASTER_ID']};
         }
         return callback(utility);
        }
    });
}