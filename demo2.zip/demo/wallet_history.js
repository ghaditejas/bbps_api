const async = require('async');
const mysql = require('mysql');
const invoice = require('./invoice')
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'partnerpay'
});
mc.connect();
module.exports.get_merchant_details = function (test, callback) {
    mc.query("SELECT m.AIRPAY_USERNAME,m.AIRPAY_PASSWORD,ap.WALLET_TOKEN FROM tbl_partner_master as m JOIN api_user as ap on m.AIRPAY_MERCHANT_ID = ap.MERCID WHERE AIRPAY_MERCHANT_ID = '" + test.merchantid + "'", function (error, results, fields) {
        if (error) {
            return callback(false);
        } else if (results.length == 0) {
            return callback(false);
        } else {
            return callback(results[0]);
            // module.export. false;
        }
    });
}